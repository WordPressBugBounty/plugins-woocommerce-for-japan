<?php
/**
 * Japan correspondence of COD payments
 *
 * @class       JP4WC_COD_Fee
 * @extends     WC_Gateway_COD
 * @version     2.9.0
 * @package     WooCommerce/Classes/Payment
 * @author      Artisan Workshop
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Japan correspondence of COD payments
 *
 * @class       JP4WC_COD_Fee
 * @extends     WC_Gateway_COD
 * @version     2.9.0
 * @package     WooCommerce/Classes/Payment
 * @author      Artisan Workshop
 */
class JP4WC_COD_Fee extends WC_Gateway_COD {

	/**
	 * Current gateway.
	 *
	 * @var string
	 */
	public $current_gateway;

	/**
	 * Current extra charge amount.
	 *
	 * @var double
	 */
	public $current_extra_charge_amount;

	/**
	 * COD fee settings
	 *
	 * @var array
	 */
	public $extra_charge_terms_of_use;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->current_gateway             = null;
		$this->current_extra_charge_amount = 0;

		parent::__construct();
		$this->add_form_fields();

		// BACS account fields shown on the thanks page and in emails.
		$this->extra_charge_terms_of_use = get_option(
			'woocommerce_cod_fees',
			array(
				array(
					'cod_fee' => $this->get_option( 'cod_fee' ),
					'cod_max' => $this->get_option( 'cod_max' ),
				),
			)
		);

		// Hooks & Filters.
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts_frontend' ) );
		add_action( 'woocommerce_update_options_payment_gateways_cod', array( $this, 'save_account_details' ) );
		add_filter( 'woocommerce_cart_calculate_fees', array( $this, 'jp4wc_calculate_order_totals' ), 1001 );
		add_filter( 'woocommerce_cart_totals_fee_html', array( $this, 'jp4wc_add_tax_label_to_fee_html' ), 10, 2 );
	}

	/**
	 * Enqueues scripts and styles for the frontend.
	 *
	 * Handles the registration and enqueuing of JavaScript and CSS files
	 * required for the COD (Cash on Delivery) fee functionality on the frontend.
	 *
	 * @return void
	 */
	public function enqueue_scripts_frontend() {
		if ( ! is_checkout() ) {
			return;
		}

		if ( jp4wc_is_using_checkout_blocks() ) {
			return;
		}

		$min = ! defined( 'SCRIPT_DEBUG' ) || ! SCRIPT_DEBUG ? '.min' : '';
		wp_enqueue_script( 'wc-pf-checkout', JP4WC_URL_PATH . 'assets/js/checkout' . $min . '.js', array( 'jquery' ), JP4WC_VERSION, true );
	}

	/**
	 * Initialize Gateway Settings Form Fields.
	 */
	public function add_form_fields() {
		foreach ( $this->form_fields as $key => $value ) {
			$current_fields[ $key ] = $value;
		}
		$current_fields['extra_cod_title']             = array(
			'title' => __( 'Extra charge for COD method', 'woocommerce-for-japan' ),
			'type'  => 'title',
		);
		$current_fields['extra_charge_name']           = array(
			'title'       => __( 'Fee name', 'woocommerce-for-japan' ),
			'type'        => 'text',
			'description' => '',
			'default'     => __( 'COD Payment method fee', 'woocommerce-for-japan' ),
		);
		$current_fields['extra_charge_amount']         = array(
			'title' => __( 'Extra charge amount', 'woocommerce-for-japan' ),
			'type'  => 'number',
			'css'   => 'width:70px;',
		);
		$current_fields['extra_charge_max_cart_value'] = array(
			'title'       => __( 'Maximum cart value to which adding fee', 'woocommerce-for-japan' ),
			'type'        => 'number',
			'css'         => 'width:70px;',
			'description' => __( 'If you dont need this setting, please set empty, 0.', 'woocommerce-for-japan' ),
		);
		$current_fields['extra_charge_calc_taxes']     = array(
			'title'   => __( 'Includes taxes', 'woocommerce-for-japan' ),
			'type'    => 'select',
			'options' => array(
				'no-tax'   => __( 'Do not calculate taxes', 'woocommerce-for-japan' ),
				'tax-incl' => __( 'The fee is taxes included', 'woocommerce-for-japan' ),
				'tax-excl' => __( 'The fee is taxes excluded', 'woocommerce-for-japan' ),
			),
		);
		$current_fields['extra_charge_terms_of_use']   = array(
			'type' => 'terms_of_use_details',
		);
		$this->form_fields                             = $current_fields;
	}

	/**
	 * Generate account details html.
	 *
	 * @return string The HTML markup for tax class setting
	 */
	public function generate_terms_of_use_details_html() {
		$tax_class = get_option( 'jp4wc_tax_class_for_cod' );
		$tax_class = empty( $tax_class ) ? 'standard' : $tax_class;

		ob_start();

		?>
		<tr valign="top" id="tax_class_setting">
			<th scope="row" class="titledesc"><?php esc_html_e( 'Tax Class:', 'woocommerce-for-japan' ); ?></th>
			<td class="forminp" id="tax_class_setting">
			<select name="jp4wc_tax_class_for_cod">
			<?php foreach ( jp4wc_get_fee_tax_classes() as $tax_class_id => $tax_class_name ) : ?>
					<option value="<?php echo esc_attr( $tax_class_id ); ?>" <?php echo selected( $tax_class, $tax_class_id, true ); ?>><?php echo esc_html( $tax_class_name ); ?></option>
			<?php endforeach; ?>
			</select>
			</td>
		</tr>
		<tr valign="top" id="terms_of_use_details">
			<th scope="row" class="titledesc"><?php esc_html_e( 'Charge amount of details:', 'woocommerce-for-japan' ); ?></th>
			<td class="forminp" id="bacs_accounts">
				<div class="wc_input_table_wrapper">
					<table class="widefat wc_input_table sortable" cellspacing="0">
						<thead>
						<tr>
							<th class="sort">&nbsp;</th>
							<th><?php esc_html_e( 'Min order amount (¥)', 'woocommerce-for-japan' ); ?></th>
							<th><?php esc_html_e( 'COD fee (¥)', 'woocommerce-for-japan' ); ?></th>
						</tr>
						</thead>
						<tbody class="accounts">
						<?php
						$i = -1;
						if ( $this->extra_charge_terms_of_use ) {
							foreach ( $this->extra_charge_terms_of_use as $cod_fee ) {
								++$i;

								echo '<tr class="account">
										<td class="sort"></td>
										<td><input type="text" value="' . esc_attr( wp_unslash( $cod_fee['cod_max'] ) ) . '" name="cod_max[' . esc_attr( $i ) . ']" /></td>
										<td><input type="text" value="' . esc_attr( wp_unslash( $cod_fee['cod_fee'] ) ) . '" name="cod_fee[' . esc_attr( $i ) . ']" /></td>
									</tr>';
							}
						}
						?>
						</tbody>
						<tfoot>
						<tr>
							<th colspan="7"><a href="#" class="add button"><?php esc_html_e( '+ Add Charge amount', 'woocommerce-for-japan' ); ?></a> <a href="#" class="remove_rows button"><?php esc_html_e( 'Remove selected Charge amount(s)', 'woocommerce-for-japan' ); ?></a></th>
						</tr>
						</tfoot>
					</table>
				</div>
				<script type="text/javascript">
					jQuery(function() {
						jQuery('#bacs_accounts').on( 'click', 'a.add', function(){

							var size = jQuery('#bacs_accounts').find('tbody .account').length;

							jQuery('<tr class="account">\
									<td class="sort"></td>\
									<td><input type="text" name="cod_max[' + size + ']" /></td>\
									<td><input type="text" name="cod_fee[' + size + ']" /></td>\
								</tr>').appendTo('#bacs_accounts table tbody');

							return false;
						});
					});
				</script>
				<p class="cod-charge-note"><?php esc_html_e( 'Note : This function is only available to PRO purchasers.', 'woocommerce-for-japan' ); ?></p>
			</td>
		</tr>
		<?php
		return ob_get_clean();
	}

	/**
	 * Save account details table.
	 */
	public function save_account_details() {

		$fees = array();

		$nonce = isset( $_POST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ) : '';
		if ( isset( $_POST['cod_fee'] ) && isset( $_POST['cod_max'] ) && wp_verify_nonce( $nonce, 'woocommerce-settings' ) ) {
			$cod_fees = wc_clean( array_map( 'sanitize_text_field', wp_unslash( $_POST['cod_fee'] ) ) );
			$cod_maxs = wc_clean( array_map( 'sanitize_text_field', wp_unslash( $_POST['cod_max'] ) ) );

			foreach ( $cod_fees as $i => $name ) {
				if ( ! isset( $cod_fees[ $i ] ) ) {
					continue;
				}

				$fees[] = array(
					'cod_fee' => $cod_fees[ $i ],
					'cod_max' => $cod_maxs[ $i ],
				);
			}

			if ( isset( $_POST['jp4wc_tax_class_for_cod'] ) ) {
				update_option( 'jp4wc_tax_class_for_cod', sanitize_text_field( wp_unslash( $_POST['jp4wc_tax_class_for_cod'] ) ) );
			}
		}
		update_option( 'woocommerce_cod_fees', $fees );
	}


	/**
	 * Get merged COD fee settings.
	 *
	 * JP4WC admin UI stores values under the wc4jp- prefix via the REST API.
	 * These take precedence over anything in woocommerce_cod_settings so that
	 * the two setting pages stay in sync regardless of which one was last saved.
	 *
	 * @return array
	 */
	private static function get_cod_fee_settings() {
		$cod_setting = get_option( 'woocommerce_cod_settings', array() );
		if ( ! is_array( $cod_setting ) ) {
			$cod_setting = array();
		}

		foreach ( array( 'extra_charge_name', 'extra_charge_amount', 'extra_charge_max_cart_value', 'extra_charge_calc_taxes' ) as $key ) {
			$value = get_option( 'wc4jp-' . $key, null );
			if ( null !== $value ) {
				$cod_setting[ $key ] = $value;
			}
		}

		return $cod_setting;
	}

	/**
	 * Get COD2 fee settings from the gateway options.
	 *
	 * @return array
	 */
	private static function get_cod2_fee_settings() {
		$cod2_setting = get_option( 'woocommerce_cod2_settings', array() );
		return is_array( $cod2_setting ) ? $cod2_setting : array();
	}

	/**
	 * Write a debug log entry when COD2 debug mode is enabled.
	 *
	 * @param string $message Log message.
	 * @param array  $context Optional key-value context data.
	 */
	private static function cod2_log( $message, array $context = array() ) {
		$settings = get_option( 'woocommerce_cod2_settings', array() );
		if ( empty( $settings['debug_mode'] ) || 'yes' !== $settings['debug_mode'] ) {
			return;
		}
		$logger = wc_get_logger();
		if ( ! empty( $context ) ) {
			$pairs = array();
			foreach ( $context as $k => $v ) {
				$pairs[] = $k . '=' . ( is_array( $v ) || is_object( $v ) ? wp_json_encode( $v ) : $v );
			}
			$message .= ' | ' . implode( ', ', $pairs );
		}
		$logger->debug( $message, array( 'source' => 'jp4wc-cod2-fee' ) );
	}

	/**
	 * Remove the JP4WC gateway fee from the cart by its fixed fee ID.
	 */
	private static function remove_fee_by_id() {
		$fees = WC()->cart->get_fees();
		foreach ( $fees as $key => $fee ) {
			if ( 'jp4wc_gateway_fee' === $fee->id ) {
				unset( $fees[ $key ] );
			}
		}
		WC()->cart->fees_api()->set_fees( $fees );
	}

	/**
	 * Add extra charge to cart totals
	 *
	 * @param object $cart Cart object.
	 * @return mixed
	 */
	public function jp4wc_calculate_order_totals( $cart ) {
		// Allow AJAX requests (e.g. classic checkout's update_order_review via admin-ajax.php)
		// because is_admin() returns true for all admin-ajax.php calls regardless of origin.
		if ( ( is_admin() && ! wp_doing_ajax() ) || 0 === $cart->get_cart_contents_count() ) {
			return;
		}
		// Only calculate fees during checkout (page load, Classic Checkout AJAX, or Block Checkout REST).
		// Prevents fee from appearing on the cart page.
		if ( ! is_checkout() && ! wp_doing_ajax() && ! ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}
		// For Classic Checkout AJAX, use chosen_payment_method (updated by WC AJAX handler).
		// For Block Checkout REST, use jp4wc_gateway_id (updated by extensionCartUpdate).
		// This prevents stale jp4wc_gateway_id from overriding the current selection in Classic Checkout.
		if ( wp_doing_ajax() ) {
			$current_gateway_id = WC()->session->get( 'chosen_payment_method' );
		} else {
			$current_gateway_id = WC()->session->get( 'jp4wc_gateway_id' );
			$current_gateway_id = empty( $current_gateway_id ) ? WC()->session->get( 'chosen_payment_method' ) : $current_gateway_id;
		}

		if ( empty( $current_gateway_id ) ) {
			return;
		}

		// Load settings for cod or cod2; remove any fee and bail for other gateways.
		if ( 'cod' === $current_gateway_id ) {
			$cod_setting = self::get_cod_fee_settings();
		} elseif ( 'cod2' === $current_gateway_id ) {
			$cod_setting = self::get_cod2_fee_settings();
			self::cod2_log(
				'[START] jp4wc_calculate_order_totals called',
				array(
					'gateway'                => $current_gateway_id,
					'is_ajax'                => wp_doing_ajax() ? 'yes' : 'no',
					'is_rest'                => ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ? 'yes' : 'no',
					'cart_contents_total'    => $cart->cart_contents_total,
					'cart_subtotal'          => $cart->subtotal,
					'cart_subtotal_ex_tax'   => $cart->subtotal_ex_tax,
					'cart_contents_count'    => $cart->get_cart_contents_count(),
					'chosen_payment_session' => WC()->session->get( 'chosen_payment_method' ),
					'jp4wc_gateway_session'  => WC()->session->get( 'jp4wc_gateway_id' ),
					'shipping_total'         => $cart->get_shipping_total(),
					'extra_charge_amount'    => isset( $cod_setting['extra_charge_amount'] ) ? $cod_setting['extra_charge_amount'] : '(not set)',
					'extra_charge_max'       => isset( $cod_setting['extra_charge_max_cart_value'] ) ? $cod_setting['extra_charge_max_cart_value'] : '(not set)',
					'calc_taxes'             => isset( $cod_setting['extra_charge_calc_taxes'] ) ? $cod_setting['extra_charge_calc_taxes'] : '(not set)',
				)
			);
		} else {
			self::remove_fee_by_id();
			return;
		}

		/**
		 * Filter the COD/COD2 fee settings array.
		 * PRO version can use this to inject tiered fee tables or other advanced settings.
		 *
		 * @since 2.9.7
		 * @param array  $cod_setting        The gateway settings option array.
		 * @param string $current_gateway_id The currently selected payment method ID ('cod' or 'cod2').
		 */
		$cod_setting = apply_filters( 'jp4wc_cod_fee_settings', $cod_setting, $current_gateway_id );

		if ( 'cod2' === $current_gateway_id ) {
			self::cod2_log(
				'[SETTINGS-FILTER] After jp4wc_cod_fee_settings filter (PRO may have modified these)',
				array(
					'extra_charge_amount'         => isset( $cod_setting['extra_charge_amount'] ) ? $cod_setting['extra_charge_amount'] : '(not set)',
					'extra_charge_max_cart_value' => isset( $cod_setting['extra_charge_max_cart_value'] ) ? $cod_setting['extra_charge_max_cart_value'] : '(not set)',
				)
			);
		}

		$extra_charge_name           = isset( $cod_setting['extra_charge_name'] ) ? $cod_setting['extra_charge_name'] : '';
		$extra_charge_amount         = isset( $cod_setting['extra_charge_amount'] ) ? floatval( $cod_setting['extra_charge_amount'] ) : 0;
		$extra_charge_max_cart_value = isset( $cod_setting['extra_charge_max_cart_value'] ) ? $cod_setting['extra_charge_max_cart_value'] : '';
		$calc_taxes                  = isset( $cod_setting['extra_charge_calc_taxes'] ) ? $cod_setting['extra_charge_calc_taxes'] : 'no-tax';

		// Normalize legacy yes/no values saved by the React admin UI before the 3-way select was introduced.
		if ( 'yes' === $calc_taxes ) {
			$calc_taxes = 'tax-excl';
		} elseif ( 'no' === $calc_taxes || '' === $calc_taxes ) {
			$calc_taxes = 'no-tax';
		}

		// Use the subtotal that matches what is displayed at checkout so the
		// threshold setting behaves as the shop admin expects.
		// display_prices_including_tax() checks woocommerce_tax_display_cart (the
		// cart/checkout display setting), not woocommerce_prices_include_tax (the
		// price-entry setting) — these can differ, so using the display setting is correct.
		$subtotal = $cart->display_prices_including_tax() ? $cart->subtotal : $cart->subtotal_ex_tax;

		// Remove fee and bail if cart total exceeds the max value threshold.
		if ( ! empty( $extra_charge_max_cart_value ) && floatval( $extra_charge_max_cart_value ) < $subtotal ) {
			if ( 'cod2' === $current_gateway_id ) {
				self::cod2_log(
					'[MAX] Cart subtotal exceeds max → fee removed (free)',
					array(
						'subtotal'                    => $subtotal,
						'display_prices_incl_tax'     => $cart->display_prices_including_tax() ? 'yes' : 'no',
						'extra_charge_max_cart_value' => floatval( $extra_charge_max_cart_value ),
						'comparison'                  => floatval( $extra_charge_max_cart_value ) . ' < ' . $subtotal . ' = true',
					)
				);
			}
			self::remove_fee( $extra_charge_name );
			return;
		}

		if ( 'cod2' === $current_gateway_id ) {
			self::cod2_log(
				'[MAX] Max cart value check passed → fee will be applied',
				array(
					'subtotal'                    => $subtotal,
					'display_prices_incl_tax'     => $cart->display_prices_including_tax() ? 'yes' : 'no',
					'extra_charge_max_cart_value' => '' === $extra_charge_max_cart_value ? '(empty/disabled)' : floatval( $extra_charge_max_cart_value ),
					'extra_charge_amount'         => $extra_charge_amount,
				)
			);
		}

		if ( 0.0 === $extra_charge_amount ) {
			if ( 'cod2' === $current_gateway_id ) {
				self::cod2_log( '[SKIP] extra_charge_amount is 0.0 → no fee added' );
			}
			return;
		}

		// Get gateway object for use in filters.
		$available_gateways = WC()->payment_gateways ? WC()->payment_gateways->get_available_payment_gateways() : array();
		$current_gateway    = isset( $available_gateways[ $current_gateway_id ] ) ? $available_gateways[ $current_gateway_id ] : null;

		// Tax calculation.
		$taxable = false;
		if ( 'no-tax' !== $calc_taxes ) {
			$taxable   = true;
			$tax       = new WC_Tax();
			$base_rate = $tax->get_base_tax_rates();
			$taxrates  = array_shift( $base_rate );
			$taxrate   = floatval( $taxrates['rate'] ) / 100;
			if ( 'tax-incl' === $calc_taxes ) {
				$taxes                = $extra_charge_amount - ( $extra_charge_amount / ( 1 + $taxrate ) );
				$extra_charge_amount -= $taxes;
			}
			// tax-excl: WooCommerce calculates tax automatically via taxable=true and tax_class.
		}

		/**
		 * Filter the COD fee display name.
		 * PRO version can use this to customise the label shown in cart/order.
		 *
		 * @since 2.9.7
		 * @param string          $extra_charge_name The fee display name.
		 * @param float           $subtotal          Cart subtotal (excl. tax).
		 * @param WC_Gateway|null $current_gateway   The current payment gateway object.
		 */
		$extra_charge_name = apply_filters( 'jp4wc_cod_fee_name', $extra_charge_name, $subtotal, $current_gateway );

		/**
		 * Filter the COD fee amount (tax-excluded).
		 * PRO version can use this to implement tiered fees based on cart total.
		 *
		 * @since 2.9.7
		 * @param float           $extra_charge_amount The fee amount (excl. tax).
		 * @param float           $subtotal            Cart subtotal (excl. tax).
		 * @param WC_Gateway|null $current_gateway     The current payment gateway object.
		 */
		$extra_charge_amount = apply_filters( 'jp4wc_cod_fee_amount', $extra_charge_amount, $subtotal, $current_gateway );
		// Backward-compatible filters.
		$extra_charge_amount = apply_filters( 'jp4wc_cod_amount', $extra_charge_amount, $subtotal, $current_gateway );
		$extra_charge_amount = apply_filters( 'jp4wc_' . $current_gateway_id . '_amount', $extra_charge_amount, $subtotal, $current_gateway );

		if ( 'cod2' === $current_gateway_id ) {
			self::cod2_log(
				'[FILTER] After amount filters',
				array(
					'extra_charge_amount_after_filters' => $extra_charge_amount,
				)
			);
		}

		$do_apply = 0 !== floatval( $extra_charge_amount );

		/**
		 * Filter whether the COD fee should be applied.
		 * PRO version can add custom eligibility conditions (e.g. specific shipping zones).
		 *
		 * @since 2.9.7
		 * @param bool            $do_apply            Whether to apply the fee.
		 * @param float           $extra_charge_amount The fee amount (excl. tax).
		 * @param float           $subtotal            Cart subtotal (excl. tax).
		 * @param WC_Gateway|null $current_gateway     The current payment gateway object.
		 * @param WC_Cart         $cart                The cart object.
		 */
		$do_apply = apply_filters( 'jp4wc_cod_fee_is_applicable', $do_apply, $extra_charge_amount, $subtotal, $current_gateway, $cart );
		// Backward-compatible filters.
		$do_apply = apply_filters( 'jp4wc_apply', $do_apply, $extra_charge_amount, $subtotal, $current_gateway, $cart );
		$do_apply = apply_filters( 'jp4wc_apply_for_' . $current_gateway_id, $do_apply, $extra_charge_amount, $subtotal, $current_gateway );

		if ( 'cod2' === $current_gateway_id ) {
			self::cod2_log(
				'[APPLY] Final applicability after all filters (jp4wc_cod_fee_is_applicable, jp4wc_apply, jp4wc_apply_for_cod2)',
				array(
					'do_apply'            => $do_apply ? 'true' : 'false',
					'extra_charge_amount' => $extra_charge_amount,
				)
			);
		}

		if ( ! $do_apply ) {
			self::remove_fee( $extra_charge_name );
			return;
		}

		// Tax class — use gateway-specific option so COD2 uses its own setting.
		if ( 'cod2' === $current_gateway_id ) {
			$tax_class = get_option( 'jp4wc_tax_class_for_cod2' );
		} else {
			$tax_class = get_option( 'jp4wc_tax_class_for_cod' );
			if ( false === $tax_class ) {
				$tax_class = get_option( 'wc4jp-extra_charge_tax_class' );
			}
		}
		$tax_class = empty( $tax_class ) ? 'standard' : $tax_class;

		/**
		 * Filter the tax class applied to the COD fee.
		 * PRO version can use this to apply a reduced rate or zero rate.
		 *
		 * @since 2.9.7
		 * @param string          $tax_class           Tax class slug (e.g. 'standard', 'reduced-rate').
		 * @param float           $extra_charge_amount The fee amount (excl. tax).
		 * @param WC_Gateway|null $current_gateway     The current payment gateway object.
		 */
		$tax_class = apply_filters( 'jp4wc_cod_fee_tax_class', $tax_class, $extra_charge_amount, $current_gateway );

		// Prevent duplicate fees.
		foreach ( $cart->get_fees() as $fee ) {
			if ( 'jp4wc_gateway_fee' === $fee->id ) {
				if ( 'cod2' === $current_gateway_id ) {
					self::cod2_log( '[SKIP] Fee jp4wc_gateway_fee already exists → skip duplicate' );
				}
				return;
			}
		}

		if ( 'cod2' === $current_gateway_id ) {
			self::cod2_log(
				'[ADD] Adding fee to cart',
				array(
					'id'        => 'jp4wc_gateway_fee',
					'name'      => $extra_charge_name,
					'amount'    => $extra_charge_amount,
					'taxable'   => $taxable ? 'true' : 'false',
					'tax_class' => $tax_class,
				)
			);
		}

		$cart->fees_api()->add_fee(
			array(
				'id'        => 'jp4wc_gateway_fee',
				'name'      => $extra_charge_name,
				'amount'    => $extra_charge_amount,
				'taxable'   => $taxable,
				'tax_class' => $tax_class,
			)
		);
	}


	/**
	 * Add Gateway Total Fee.
	 *
	 * @param object      $cart_obj   Cart object.
	 * @param string|null $gateway_id Payment gateway ID. When null, resolved from session.
	 * @return array { fee_value: float, fee_text: string }
	 */
	public static function get_gateway_fee_value( $cart_obj, $gateway_id = null ) {
		$fee_value = array(
			'fee_value' => 0,
			'fee_text'  => '',
		);

		if ( null === $gateway_id ) {
			$gateway_id = WC()->session->get( 'jp4wc_gateway_id' );
			$gateway_id = empty( $gateway_id ) ? WC()->session->get( 'chosen_payment_method' ) : $gateway_id;
		}

		if ( empty( $gateway_id ) ) {
			return $fee_value;
		}

		if ( 'cod' === $gateway_id ) {
			$cod_setting = self::get_cod_fee_settings();
		} elseif ( 'cod2' === $gateway_id ) {
			$cod_setting = self::get_cod2_fee_settings();
		} else {
			self::remove_fee_by_id();
			return $fee_value;
		}

		$value    = isset( $cod_setting['extra_charge_amount'] ) ? $cod_setting['extra_charge_amount'] : 0;
		$fee_text = isset( $cod_setting['extra_charge_name'] ) ? $cod_setting['extra_charge_name'] : '';

		return array(
			'fee_value' => $value,
			'fee_text'  => $fee_text,
		);
	}

	/**
	 * Add "(incl. tax)" or "(excl. tax)" label to the COD fee in cart/checkout totals.
	 *
	 * Mirrors the label logic used by WC_Cart::get_cart_subtotal() and
	 * get_cart_shipping_total() in WooCommerce core.
	 *
	 * @param string   $fee_html Fee HTML string.
	 * @param stdClass $fee      Fee object with id, total, tax properties.
	 * @return string
	 */
	public function jp4wc_add_tax_label_to_fee_html( $fee_html, $fee ) {
		if ( 'jp4wc_gateway_fee' !== $fee->id || ! wc_tax_enabled() || $fee->tax <= 0 ) {
			return $fee_html;
		}

		if ( WC()->cart->display_prices_including_tax() && ! wc_prices_include_tax() ) {
			$fee_html .= ' <small class="tax_label">' . WC()->countries->inc_tax_or_vat() . '</small>';
		} elseif ( ! WC()->cart->display_prices_including_tax() && wc_prices_include_tax() ) {
			$fee_html .= ' <small class="tax_label">' . WC()->countries->ex_tax_or_vat() . '</small>';
		}

		return $fee_html;
	}

	/**
	 * Remove Fee from Cart
	 *
	 * @param string $fee_text Fee Text.
	 */
	public static function remove_fee( $fee_text ) {
		$fees = WC()->cart->get_fees();

		foreach ( $fees as $key => $fee ) {
			if ( ( $fees[ $key ]->name === $fee_text ) ) {
				unset( $fees[ $key ] );
			}
		}

		WC()->cart->fees_api()->set_fees( $fees );
	}
}
