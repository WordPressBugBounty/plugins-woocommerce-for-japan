<?php
/**
 * WC_Paidy_Admin_Wizard class file.
 *
 * Handles the admin wizard for Paidy onboarding.
 *
 * @package Paidy_WC
 */

use Automattic\WooCommerce\Utilities\ArrayUtil;

/**
 * Class WC_Paidy_Admin_Wizard
 *
 * Handles the admin wizard for Paidy onboarding.
 */
class WC_Paidy_Admin_Wizard {

	/**
	 * Payment gateway ID.
	 *
	 * @var string
	 */
	public $id = 'paidy';

	/**
	 * Paidy gateway settings.
	 *
	 * @var array
	 */
	public $paidy_settings;

	/**
	 * Paidy onboarding settings.
	 *
	 * @var array
	 */
	public $paidy_on_boarding_settings;

	/**
	 * Constructor for the WC_Paidy_Admin_Wizard class.
	 */
	public function __construct() {
		$this->paidy_settings             = get_option( 'woocommerce_' . $this->id . '_settings' );
		$this->paidy_on_boarding_settings = get_option( 'woocommerce_paidy_on_boarding_settings' );
		add_action( 'admin_menu', array( $this, 'paidy_on_boarding_add_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'wc_admin_paidy_on_boarding_scripts' ) );
		add_action( 'init', array( $this, 'paidy_on_boarding_settings' ) );
		add_filter( 'woocommerce_gateway_method_description', array( $this, 'paidy_method_description' ), 20, 2 );
		add_action( 'woocommerce_settings_tabs_checkout', array( $this, 'paidy_after_settings_checkout' ) );
		if ( isset( $this->paidy_settings['api_public_key'] ) && isset( $this->paidy_settings['test_api_public_key'] ) ) {
			add_action( 'updated_option', array( $this, 'change_paidy_on_boarding_settings' ), 10, 3 );
			add_action( 'add_option', array( $this, 'add_paidy_on_boarding_settings' ), 10, 2 );
		}
		add_action( 'admin_init', array( $this, 'paidy_handle_wizard_false_redirect' ) );
	}

	/**
	 * Get screen id.
	 *
	 * @since 1.0.0
	 */
	public function get_screen_id() {
		return '/paidy-on-boarding';
	}

	/**
	 * Adds the Paidy On Boarding page to the WooCommerce admin menu.
	 */
	public function paidy_on_boarding_add_menu() {
		if ( ! function_exists( 'wc_admin_register_page' ) ) {
			return;
		}
		wc_admin_register_page(
			array(
				'id'         => 'paidy-on-boarding',
				'title'      => __( 'Paidy On Boarding', 'woocommerce-for-japan' ),
				'parent'     => '',
				'path'       => '/paidy-on-boarding',
				'capability' => 'manage_woocommerce',
			),
		);
	}

	/**
	 * Enqueues the scripts and styles for the Paidy onboarding wizard.
	 */
	public function wc_admin_paidy_on_boarding_scripts() {
		$screen = get_current_screen();
		if ( ! isset( $_GET['path'] ) || ( isset( $_GET['path'] ) && $this->get_screen_id() !== $_GET['path'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}

		$asset_file = WC_PAIDY_ASSETS_ABSPATH . 'wizard/paidy.asset.php';
		if ( ! file_exists( $asset_file ) ) {
			return;
		}

		$asset  = include $asset_file;
		$handle = 'paidy-on-boarding-script';

		wp_enqueue_script(
			$handle,
			WC_PAIDY_BLOCKS_URL . 'wizard/paidy.js',
			$asset['dependencies'],
			$asset['version'],
			true
		);

		wp_enqueue_style(
			$handle,
			WC_PAIDY_BLOCKS_URL . 'wizard/paidy.css',
			array_filter(
				$asset['dependencies'],
				function ( $style ) {
					return wp_style_is( $style, 'registered' );
				}
			),
			$asset['version'],
		);

		// Set translations.
		wp_set_script_translations(
			$handle,
			'woocommerce-for-japan', // Load translations from the plugin's i18n directory.
			WC_PAIDY_ABSPATH . 'i18n'
		);

		// Setting data.
		$rest_url     = get_rest_url();
		$paidy_ad_url = 'https://paidy.com/campaign/merchant/202404_WW';
		$plugin_name  = 'Japanized for WooCommerce'; // Translated plugin name.
		$has_api_keys = isset( $this->paidy_settings['api_public_key'] )
			&& ! empty( $this->paidy_settings['api_public_key'] )
			&& isset( $this->paidy_settings['api_secret_key'] )
			&& ! empty( $this->paidy_settings['api_secret_key'] )
			&& isset( $this->paidy_settings['test_api_public_key'] )
			&& ! empty( $this->paidy_settings['test_api_public_key'] )
			&& isset( $this->paidy_settings['test_api_secret_key'] )
			&& ! empty( $this->paidy_settings['test_api_secret_key'] );
		wp_localize_script(
			$handle,
			'paidyForWcSettings',
			array(
				'restUrl'      => $rest_url,
				'paidyAdUrl'   => $paidy_ad_url,
				'nonWizardUrl' => admin_url( 'admin.php?page=wc-settings&tab=checkout&section=paidy&wizard=false' ),
				'pluginName'   => $plugin_name,
				'hasApiKeys'   => $has_api_keys,
			)
		);
	}

	/**
	 * Registers the setting and defines its type and default value.
	 */
	public function paidy_on_boarding_settings() {
		$default = array(
			'currentStep'                     => 0,
			'storeName'                       => '',
			'siteName'                        => get_bloginfo( 'name' ),
			'storeUrl'                        => get_bloginfo( 'url' ),
			'registEmail'                     => get_bloginfo( 'admin_email' ),
			'annualGrossValue'                => 'less-than-10-million-yen',
			'averagePurchaseAmount'           => 'less-than-50000-yen',
			'securitySurvey01RadioControl'    => '',
			'securitySurvey01TextControl'     => '',
			'securitySurvey11CheckControl'    => false,
			'securitySurvey12CheckControl'    => false,
			'securitySurvey13CheckControl'    => false,
			'securitySurvey14CheckControl'    => false,
			'securitySurvey10TextAreaControl' => '',
			'securitySurvey08RadioControl'    => 'yes',
			'securitySurvey09RadioControl'    => 'yes',
		);
		$schema  = array(
			'type'       => 'object',
			'properties' => array(
				'currentStep'                     => array(
					'type' => 'integer',
				),
				'storeName'                       => array(
					'type' => 'string',
				),
				'siteName'                        => array(
					'type' => 'string',
				),
				'storeUrl'                        => array(
					'type' => 'string',
				),
				'registEmail'                     => array(
					'type' => 'string',
				),
				'contactPhone'                    => array(
					'type' => 'string',
				),
				'representativeLastName'          => array(
					'type' => 'string',
				),
				'representativeFirstName'         => array(
					'type' => 'string',
				),
				'representativeLastNameKana'      => array(
					'type' => 'string',
				),
				'representativeFirstNameKana'     => array(
					'type' => 'string',
				),
				'representativeDateOfBirth'       => array(
					'type' => 'date',
				),
				'annualGrossValue'                => array(
					'type' => 'string',
				),
				'averagePurchaseAmount'           => array(
					'type' => 'string',
				),
				'securitySurvey01RadioControl'    => array(
					'type' => 'string',
				),
				'securitySurvey01TextControl'     => array(
					'type' => 'string',
				),
				'securitySurvey11CheckControl'    => array(
					'type' => 'boolean',
				),
				'securitySurvey12CheckControl'    => array(
					'type' => 'boolean',
				),
				'securitySurvey13CheckControl'    => array(
					'type' => 'boolean',
				),
				'securitySurvey14CheckControl'    => array(
					'type' => 'boolean',
				),
				'securitySurvey10TextAreaControl' => array(
					'type' => 'string',
				),
				'securitySurvey08RadioControl'    => array(
					'type' => 'string',
				),
				'securitySurvey09RadioControl'    => array(
					'type' => 'string',
				),
			),
		);

		register_setting(
			'options',
			'woocommerce_paidy_on_boarding_settings',
			array(
				'type'              => 'object',
				'default'           => $default,
				'show_in_rest'      => array(
					'schema'           => $schema,
					'prepare_callback' => function ( $value ) {
						if ( empty( $value ) || ! is_array( $value ) ) {
							return $this->paidy_on_boarding_settings();
						}
						return $value;
					},
				),
				'sanitize_callback' => array( $this, 'paidy_sanitize_on_boarding_settings' ),
			)
		);

		// Application ID assigned by the intermediary, read by the wizard UI so
		// the merchant can see it on the "under review" screen. Kept outside
		// woocommerce_paidy_on_boarding_settings because that option's sanitizer
		// whitelists form fields and would strip it on the next save.
		register_setting(
			'options',
			'paidy_application_id',
			array(
				'type'              => 'string',
				'default'           => '',
				'show_in_rest'      => true,
				'sanitize_callback' => array( __CLASS__, 'sanitize_application_id' ),
			)
		);
	}

	/**
	 * Sanitize Paidy on boarding settings.
	 *
	 * @param mixed $input The input to sanitize.
	 * @return string Sanitized input.
	 */
	public function paidy_sanitize_on_boarding_settings( $input ) {
		if ( is_object( $input ) ) {
			$input = (array) $input;
		} elseif ( ! is_array( $input ) ) {
			return array();
		}
		$sanitized                = array();
		$sanitized['currentStep'] = isset( $input['currentStep'] ) ? absint( $input['currentStep'] ) : 0;

		$text_fields = array(
			'storeName',
			'siteName',
			'storeUrl',
			'registEmail',
			'contactPhone',
			'representativeLastName',
			'representativeFirstName',
			'representativeLastNameKana',
			'representativeFirstNameKana',
			'representativeDateOfBirth',
			'securitySurvey01TextControl',
			'securitySurvey10TextAreaControl',
		);

		foreach ( $text_fields as $field ) {
			$sanitized[ $field ] = isset( $input[ $field ] ) ? sanitize_text_field( $input[ $field ] ) : '';
		}

		$select_fields = array(
			'annualGrossValue',
			'averagePurchaseAmount',
			'securitySurvey01RadioControl',
			'securitySurvey08RadioControl',
			'securitySurvey09RadioControl',
		);
		foreach ( $select_fields as $field ) {
			$sanitized[ $field ] = isset( $input[ $field ] ) ? sanitize_text_field( $input[ $field ] ) : '';
		}

		$checkbox_fields = array(
			'securitySurvey11CheckControl',
			'securitySurvey12CheckControl',
			'securitySurvey13CheckControl',
			'securitySurvey14CheckControl',
		);

		foreach ( $checkbox_fields as $field ) {
			$sanitized[ $field ] = isset( $input[ $field ] ) && rest_sanitize_boolean( $input[ $field ] );
		}

		return $sanitized;
	}

	/**
	 * Handles changes to the Paidy on-boarding settings.
	 *
	 * @param string $option The option name.
	 * @param mixed  $old_value Previous value of the option.
	 * @param mixed  $value New value of the option.
	 */
	public function change_paidy_on_boarding_settings( $option, $old_value, $value ) {
		if ( 'woocommerce_paidy_on_boarding_settings' !== $option ) {
			return;
		}
		if ( isset( $value['currentStep'] ) && 2 === $value['currentStep'] && 1 === $old_value['currentStep'] ) {

			// Update the site hash and hash in options.
			if ( ! get_option( 'paidy_site_hash' ) ) {
				$site_hash = $this->generate_random_string( 16 );
				add_option( 'paidy_site_hash', $site_hash );
			} else {
				$site_hash = get_option( 'paidy_site_hash' );
			}
			$result = $this->send_apply_data_to_wcartws( $value, $site_hash );
		}
	}

	/**
	 * Sends application data to WCART web service.
	 *
	 * @param array  $value The application data to be sent.
	 * @param string $site_hash The site hash.
	 * @return bool Returns true if data was sent successfully, false otherwise.
	 */
	public function send_apply_data_to_wcartws( $value, $site_hash ) {

		$wcartws_api_url = 'https://paidy.artws.info/api/applications/';

		if ( 'less-than-10-million-yen' === $value['annualGrossValue'] ) {
			$gmv_flag = 0;
		} else {
			$gmv_flag = 1;
		}

		if ( 'less-than-50000-yen' === $value['averagePurchaseAmount'] ) {
			$average_flag = 0;
		} else {
			$average_flag = 1;
		}

		// Generate a one-time state token so the receiver endpoint can verify the
		// callback originates from an active onboarding session (not a forged request).
		// Tokens are stored keyed by their own value so parallel or retried
		// onboarding sessions do not overwrite each other's tokens. Storage is a
		// non-autoloaded option (not a transient) because the Paidy review can take
		// weeks and the callback must still verify when it finally arrives.
		$state_token = wp_generate_password( 32, false );
		$state_saved = WC_Paidy_Apply_Receiver::store_state_token( $state_token );
		if ( ! $state_saved ) {
			wc_get_logger()->error(
				'Paidy onboarding: failed to store state token option. The onboarding callback will be rejected. Check your DB.',
				array( 'source' => 'paidy-wc' )
			);
			return false;
		}

		$data_array = array(
			'site_name'      => $value['siteName'],
			'site_url'       => $value['storeUrl'],
			'trade_name'     => $value['storeName'],
			'site_hash'      => $site_hash,
			'email'          => $value['registEmail'],
			'phone'          => $value['contactPhone'],
			'ceo'            => $value['representativeLastName'] . ' ' . $value['representativeFirstName'],
			'ceo_kana'       => $value['representativeLastNameKana'] . ' ' . $value['representativeFirstNameKana'],
			'ceo_birthday'   => $value['representativeDateOfBirth'],
			'gmv_flag'       => $gmv_flag,
			'average_flag'   => $average_flag,
			'survey01'       => $value['securitySurvey01RadioControl'],
			'survey02'       => $value['securitySurvey01TextControl'],
			'survey03'       => $value['securitySurvey11CheckControl'],
			'survey04'       => $value['securitySurvey12CheckControl'],
			'survey05'       => $value['securitySurvey13CheckControl'],
			'survey06'       => $value['securitySurvey14CheckControl'],
			'survey07'       => $value['securitySurvey10TextAreaControl'],
			'survey08'       => $value['securitySurvey08RadioControl'],
			'survey09'       => $value['securitySurvey09RadioControl'],
			'state'          => $state_token,
			// Sent for support diagnostics only: the intermediary records which
			// plugin version submitted the application (state-token handling
			// differs by version, see WC_Paidy_Apply_Receiver::SIGNATURE_HEADER).
			'plugin_version' => defined( 'JP4WC_VERSION' ) ? JP4WC_VERSION : '',
		);
		$args       = array(
			'method'      => 'POST',
			'timeout'     => 15,
			'redirection' => 5,
			'httpversion' => '1.1',
			'blocking'    => true,
			'body'        => $data_array,
		);
		$response   = wp_remote_post( $wcartws_api_url, $args );

		if ( is_wp_error( $response ) ) {
			$error_message = $response->get_error_message();
			wc_get_logger()->error(
				'Paidy On Boarding API Error: ' . $error_message,
				array( 'source' => 'paidy-wc' )
			);
			// Clean up the state token: the POST never reached the intermediary,
			// so the receiver callback will never arrive to consume it.
			WC_Paidy_Apply_Receiver::consume_state_token( $state_token );
			return false;
		}

		// wp_remote_retrieve_response_code() returns '' for a WP_Error, which the
		// case above already returned on — a raw response array is guaranteed here.
		$result        = true;
		$response_code = wp_remote_retrieve_response_code( $response );
		if ( 403 === $response_code || $response_code < 200 || $response_code >= 300 ) {
			wc_get_logger()->error(
				'Paidy On Boarding API Response Code: ' . $response_code,
				array(
					'source'   => 'paidy-wc',
					'response' => $response,
				)
			);
			// Clean up the orphaned state token on HTTP-level failures as well.
			WC_Paidy_Apply_Receiver::consume_state_token( $state_token );
			$result = false;
		}

		if ( $result ) {
			$this->store_application_id( wp_remote_retrieve_body( $response ) );
		}

		return $result;
	}

	/**
	 * Persist the application ID returned by the intermediary.
	 *
	 * The ID is shown on the "under review" screen so a merchant can quote it
	 * to support, and logged so the site's own WooCommerce log ties the wizard
	 * submission to the intermediary's record.
	 *
	 * @since 2.9.16
	 *
	 * @param string $response_body Raw JSON body of the application POST response.
	 * @return void
	 */
	private function store_application_id( $response_body ) {
		$body = json_decode( (string) $response_body, true );
		if ( ! is_array( $body ) || empty( $body['application_id'] ) ) {
			return;
		}

		$application_id = self::sanitize_application_id( $body['application_id'] );
		if ( '' === $application_id ) {
			return;
		}

		update_option( 'paidy_application_id', $application_id, false );
		wc_get_logger()->info(
			'Paidy onboarding application accepted by the intermediary. Application ID: ' . $application_id,
			array( 'source' => 'paidy-wc' )
		);
	}

	/**
	 * Sanitize an application ID (e.g. WC000000571).
	 *
	 * Used both for the intermediary response and as the REST sanitize
	 * callback of the `paidy_application_id` setting.
	 *
	 * @since 2.9.16
	 *
	 * @param mixed $value Raw value.
	 * @return string Sanitized ID, or empty string if invalid.
	 */
	public static function sanitize_application_id( $value ) {
		if ( ! is_string( $value ) ) {
			return '';
		}
		// Strict allow-list on the raw (trimmed) value: reject rather than
		// strip, so markup or separators never collapse into a "valid" ID.
		$value = trim( $value );
		return 1 === preg_match( '/^[A-Za-z0-9_\-]{1,32}$/', $value ) ? $value : '';
	}

	/**
	 * Generates a random string with specified length.
	 *
	 * @param int $length The length of the string to generate (minimum 6).
	 * @return string Random string containing numbers, letters and symbols.
	 * @throws Exception If length is less than 6.
	 */
	public function generate_random_string( $length = 12 ) {
		if ( $length < 6 ) {
			throw new Exception( 'Length must be at least 6.' );
		}

		$digits  = '0123456789';
		$letters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$symbols = '!@#$%&*()-_=+';

		$all_chars = $digits . $letters . $symbols;

		$random_string = '';

		// At least two characters each of numbers, letters, and symbols.
		for ( $i = 0; $i < 2; $i++ ) {
			$random_string .= $digits[ random_int( 0, strlen( $digits ) - 1 ) ];
			$random_string .= $letters[ random_int( 0, strlen( $letters ) - 1 ) ];
			$random_string .= $symbols[ random_int( 0, strlen( $symbols ) - 1 ) ];
		}

		// Get the remaining characters (e.g. 6 characters for length=12) from all character sets.
		for ( $i = 6; $i < $length; $i++ ) {
			$random_string .= $all_chars[ random_int( 0, strlen( $all_chars ) - 1 ) ];
		}

		// Shuffle to randomize the order of letters.
		$random_string = str_shuffle( $random_string );

		return $random_string;
	}

	/**
	 * Handles additions to the Paidy on-boarding settings.
	 *
	 * @param string $option The option name.
	 * @param mixed  $value New value of the option.
	 */
	public function add_paidy_on_boarding_settings( $option, $value ) {
		if ( 'woocommerce_paidy_on_boarding_settings' !== $option ) {
			return;
		}

		if ( isset( $value['currentStep'] ) && 1 === $value['currentStep'] ) {
			// Update the site hash and hash in options.
			if ( ! get_option( 'paidy_site_hash' ) ) {
				$site_hash = $this->generate_random_string( 16 );
				add_option( 'paidy_site_hash', $site_hash );
			}
			$value['currentStep'] = 2;
			update_option( $option, $value );
		} elseif ( isset( $value['currentStep'] ) && 2 === $value['currentStep'] ) {
			// Update the site hash and hash in options.
			if ( ! get_option( 'paidy_site_hash' ) ) {
				$site_hash = $this->generate_random_string( 16 );
				add_option( 'paidy_site_hash', $site_hash );
			}
			$result = $this->send_apply_data_to_wcartws( $value, $site_hash );
		}
	}

	/**
	 * Filter to customize the payment method description.
	 *
	 * @param string             $description    The payment method description.
	 * @param WC_Payment_Gateway $payment_object The payment gateway object.
	 * @return string Modified payment method description.
	 */
	public function paidy_method_description( $description, $payment_object ) {
		if ( $payment_object->id === $this->id ) {
			// Manual entry requested via wizard=false: render the gateway
			// fields as-is instead of the onboarding UI that hides them.
			if ( $this->is_manual_settings_requested() ) {
				return $description;
			}
			if ( isset( $this->paidy_settings['api_public_key'] )
			&& isset( $this->paidy_settings['test_api_public_key'] )
			&& ( ! empty( $this->paidy_settings['api_public_key'] ) || ! empty( $this->paidy_settings['test_api_public_key'] ) )
			&& isset( $this->paidy_settings['environment'] )
			) {
				return $description;
			}
			$description .= '<div id="paidy-admin-settings"></div>';
			$description .= '<div id="paidy-payment-settings">';
		}
		return $description;
	}

	/**
	 * Outputs the closing div tag for the payment settings section.
	 */
	public function paidy_after_settings_checkout() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['section'] ) && $_GET['section'] === $this->id ) {
			// No wrapper was opened in paidy_method_description() for manual entry.
			if ( $this->is_manual_settings_requested() ) {
				return;
			}
			if ( isset( $this->paidy_settings['api_public_key'] ) && isset( $this->paidy_settings['test_api_public_key'] ) ) {
				return;
			} else {
				echo '</div>';
			}
		}
	}

	/**
	 * Lifetime of the per-user "show manual settings" flag, in seconds.
	 *
	 * @since 2.9.16
	 */
	const MANUAL_SETTINGS_TTL = 15 * MINUTE_IN_SECONDS;

	/**
	 * Transient key of the per-user "show manual settings" flag.
	 *
	 * @since 2.9.16
	 *
	 * @return string
	 */
	public static function manual_settings_transient_key() {
		return 'paidy_manual_settings_' . get_current_user_id();
	}

	/**
	 * Whether the current user asked for the plain gateway fields (wizard=false).
	 *
	 * @since 2.9.16
	 *
	 * @return bool
	 */
	public function is_manual_settings_requested() {
		return false !== get_transient( self::manual_settings_transient_key() );
	}

	/**
	 * Handles redirect when wizard=false parameter is present.
	 * Redirects to Paidy settings page.
	 */
	public function paidy_handle_wizard_false_redirect() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! isset( $_GET['page'] ) || 'wc-settings' !== $_GET['page'] ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! isset( $_GET['tab'] ) || 'checkout' !== $_GET['tab'] ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! isset( $_GET['section'] ) || $this->id !== $_GET['section'] ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! isset( $_GET['wizard'] ) || 'false' !== $_GET['wizard'] ) {
			return;
		}

		// Check user capability.
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		// Remember the request so the settings page renders the plain gateway
		// fields after the redirect below strips wizard=false. Without this
		// the page would show the onboarding/under-review UI again and keep
		// #paidy-payment-settings hidden, so manual key entry was impossible.
		set_transient( self::manual_settings_transient_key(), 1, self::MANUAL_SETTINGS_TTL );

		// Redirect to Paidy settings page (remove wizard=false parameter).
		$redirect_url = add_query_arg(
			array(
				'page'    => 'wc-settings',
				'tab'     => 'checkout',
				'section' => $this->id,
			),
			admin_url( 'admin.php' )
		);

		wp_safe_redirect( $redirect_url );
		exit;
	}
}
