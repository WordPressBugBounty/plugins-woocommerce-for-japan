<?php
/**
 * Initialise Gateway Settings Form Fields
 * Class WC_Gateway_Paidy file.
 *
 * @package WooCommerce\Gateways
 */

use ArtisanWorkshop\PluginFramework\v2_0_14 as Framework;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Paidy Payment Gateway in Japanese
 *
 * Provides a Paidy Payment Gateway in Japanese. Based on code by Shohei Tanaka.
 *
 * @class       WC_Gateway_Paidy
 * @extends     WC_Payment_Gateway
 * @version     1.4.8
 * @package     WooCommerce/Classes/Payment
 * @author      Artisan Workshop
 */
class WC_Gateway_Paidy extends WC_Payment_Gateway {

	/**
	 * Framework.
	 *
	 * @var stdClass
	 */
	public $jp4wc_framework;

	/**
	 * Settings parameter
	 *
	 * @var string
	 */
	public $paidy_description;

	/**
	 * Order button text.
	 *
	 * @var string
	 */
	public $order_button_text;

	/**
	 * Environment.
	 *
	 * @var string
	 */
	public $environment;

	/**
	 * API public key.
	 *
	 * @var string
	 */
	public $api_public_key;

	/**
	 * API secret key.
	 *
	 * @var string
	 */
	public $api_secret_key;

	/**
	 * Test API public key.
	 *
	 * @var string
	 */
	public $test_api_public_key;

	/**
	 * Test API secret key.
	 *
	 * @var string
	 */
	public $test_api_secret_key;

	/**
	 * Store name.
	 *
	 * @var string
	 */
	public $store_name;

	/**
	 * Logo image URL.
	 *
	 * @var string
	 */
	public $logo_image_url;

	/**
	 * Debug mode.
	 *
	 * @var bool
	 */
	public $debug;

	/**
	 * Webhook URL.
	 *
	 * @var string
	 */
	public $webhook;

	/**
	 * Notice email.
	 *
	 * @var string
	 */
	public $notice_email;

	/**
	 * Instructions.
	 *
	 * @var string
	 */
	public $instructions;

	/**
	 * Account details.
	 *
	 * @var string
	 */
	public $account_details;

	/**
	 * Constructor for the gateway.
	 */
	public function __construct() {
		$this->id         = 'paidy';
		$this->icon       = apply_filters( 'woocommerce_paidy_icon', WC_PAIDY_ASSETS_URL . 'images/paidy_logo_100_2023.png' );
		$this->has_fields = false;
		// translators: %s: Payment method name.
		$this->order_button_text = sprintf( __( 'Proceed to %s', 'woocommerce-for-japan' ), __( 'Paidy', 'woocommerce-for-japan' ) );

		// Create plugin fields and settings.
		$this->init_form_fields();
		$this->init_settings();

		$this->method_title       = __( 'Paidy Payment', 'woocommerce-for-japan' );
		$this->method_description = __( '"Paidy next month payment" reduces the opportunity loss due to the payment method and contributes to sales increase.', 'woocommerce-for-japan' );

		$this->supports = array(
			'products',
			'refunds',
		);

		$this->jp4wc_framework = new Framework\JP4WC_Framework();

		// Get setting values.
		foreach ( $this->settings as $key => $val ) {
			$this->$key = $val;
		}

		// Define user set variables.
		$this->title       = $this->get_option( 'title' );
		$this->description = $this->get_option( 'description' );

		// Actions Hook.
		add_action( 'woocommerce_update_options_payment_gateways', array( $this, 'process_admin_options' ) );
		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );

		add_action( 'woocommerce_receipt_' . $this->id, array( $this, 'paidy_make_order' ) );

		add_action( 'wp_enqueue_scripts', array( $this, 'paidy_token_scripts_method' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'paidy_admin_enqueue_scripts' ) );

		add_action( 'woocommerce_before_checkout_form', array( $this, 'checkout_reject_to_cancel' ) );
		add_action( 'woocommerce_thankyou_' . $this->id, array( $this, 'thankyou_completed' ) );

		// The order status callbacks are registered once by register_order_status_hooks().

		add_action( 'admin_print_footer_scripts', array( $this, 'paidy_remove_refund_button_for_processing' ), 10 );
	}

	/**
	 * Register the order status callbacks that capture, cancel and refund at Paidy.
	 *
	 * They are not registered in the constructor because this class is created more than
	 * once in a request (WooCommerce's gateway list, WC_Paidy_Endpoint), and each instance
	 * would send the same request to Paidy again. They are not left to WooCommerce's
	 * instance alone either: a request that changes an order status, such as a REST API
	 * call or a bulk action, does not always load the payment gateways.
	 *
	 * @since 2.9.17
	 */
	public static function register_order_status_hooks() {
		$hooks = array(
			'woocommerce_order_status_completed' => 'handle_order_status_completed',
			'woocommerce_order_status_processing_to_cancelled' => 'handle_order_status_processing_to_cancelled',
			'woocommerce_order_status_completed_to_cancelled' => 'handle_order_status_completed_to_cancelled',
		);
		foreach ( $hooks as $hook => $method ) {
			// WordPress keys a callback by its name and priority, so adding it again does not run it twice.
			add_action( $hook, array( __CLASS__, $method ) );
		}
	}

	/**
	 * Capture at Paidy when a Paidy order is completed.
	 *
	 * @since 2.9.17
	 *
	 * @param int $order_id Order ID.
	 */
	public static function handle_order_status_completed( $order_id ) {
		$gateway = self::get_gateway_for_order( $order_id );
		if ( $gateway ) {
			$gateway->jp4wc_order_paidy_status_completed( $order_id );
		}
	}

	/**
	 * Close the payment at Paidy when a processing Paidy order is cancelled.
	 *
	 * @since 2.9.17
	 *
	 * @param int $order_id Order ID.
	 */
	public static function handle_order_status_processing_to_cancelled( $order_id ) {
		$gateway = self::get_gateway_for_order( $order_id );
		if ( $gateway ) {
			$gateway->paidy_order_paidy_status_processing_to_cancelled( $order_id );
		}
	}

	/**
	 * Refund at Paidy when a completed Paidy order is cancelled.
	 *
	 * @since 2.9.17
	 *
	 * @param int $order_id Order ID.
	 */
	public static function handle_order_status_completed_to_cancelled( $order_id ) {
		$gateway = self::get_gateway_for_order( $order_id );
		if ( $gateway ) {
			$gateway->paidy_order_paidy_status_completed_to_cancelled( $order_id );
		}
	}

	/**
	 * The gateway instance WooCommerce has registered, for an order paid with Paidy.
	 *
	 * Orders paid by other methods return null without loading the payment gateways.
	 *
	 * @since 2.9.17
	 *
	 * @param int $order_id Order ID.
	 * @return WC_Gateway_Paidy|null
	 */
	private static function get_gateway_for_order( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order || 'paidy' !== $order->get_payment_method() ) {
			return null;
		}
		$gateways = WC()->payment_gateways()->payment_gateways();

		return isset( $gateways['paidy'] ) && $gateways['paidy'] instanceof self ? $gateways['paidy'] : null;
	}

	/**
	 * Initialise Gateway Settings Form Fields
	 */
	public function init_form_fields() {
		$this->form_fields = array(
			'enabled'             => array(
				'title'   => __( 'Enable/Disable', 'woocommerce-for-japan' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable Paidy', 'woocommerce-for-japan' ),
				'default' => 'no',
			),
			'title'               => array(
				'title'       => __( 'Title', 'woocommerce-for-japan' ),
				'type'        => 'text',
				'description' => __( 'This controls the title which the user sees during checkout.', 'woocommerce-for-japan' ),
				'default'     => __( 'Paidy Payment', 'woocommerce-for-japan' ),
				'desc_tip'    => true,
			),
			'description'         => array(
				'title'       => __( 'Description', 'woocommerce-for-japan' ),
				'type'        => 'textarea',
				'description' => __( 'Payment method description that the customer will see on your checkout.', 'woocommerce-for-japan' ),
				'default'     => __( 'No matter how many times you shop a month, you pay once in the following month. <br /> The following payment methods are available.', 'woocommerce-for-japan' ),
				'desc_tip'    => true,
			),
			'paidy_description'   => array(
				'title'             => __( 'Paidy description', 'woocommerce-for-japan' ),
				'type'              => 'textarea',
				'custom_attributes' => array( 'rows' => 6 ),
				'description'       => __( 'Payment method description for paidy explanation that the customer will see on your checkout.', 'woocommerce-for-japan' ),
				'default'           => $this->paidy_explanation(),
				'desc_tip'          => true,
			),
			'order_button_text'   => array(
				'title'       => __( 'Order Button Text', 'woocommerce-for-japan' ),
				'type'        => 'text',
				'description' => __( 'This controls the description which the user sees during checkout.', 'woocommerce-for-japan' ),
				// translators: %s: Payment method name.
				'default'     => sprintf( __( 'Proceed to %s', 'woocommerce-for-japan' ), __( 'Paidy', 'woocommerce-for-japan' ) ),
			),
			'environment'         => array(
				'title'       => __( 'Environment', 'woocommerce-for-japan' ),
				'type'        => 'select',
				'description' => __( 'This setting specifies whether you will process live transactions, or whether you will process simulated transactions using the Paidy Sandbox.', 'woocommerce-for-japan' ),
				'default'     => '',
				'desc_tip'    => true,
				'options'     => array(
					'live'    => __( 'Live', 'woocommerce-for-japan' ),
					'sandbox' => __( 'Sandbox', 'woocommerce-for-japan' ),
				),
			),
			'api_public_key'      => array(
				'title'       => __( 'API Public Key', 'woocommerce-for-japan' ),
				'type'        => 'text',
				// API Public Key.
				'description' => sprintf(
					/* translators: %s: Enter Key. */
					__( 'Please enter %s from Paidy Admin site.', 'woocommerce-for-japan' ),
					__( 'API Public Key', 'woocommerce-for-japan' )
				),
				'default'     => '',
				'desc_tip'    => true,
			),
			'api_secret_key'      => array(
				'title'       => __( 'API Secret Key', 'woocommerce-for-japan' ),
				'type'        => 'password',
				// API Secret Key.
				'description' => sprintf(
					/* translators: %s: Enter Key. */
					__( 'Please enter %s from Paidy Admin site.', 'woocommerce-for-japan' ),
					__( 'API Secret Key', 'woocommerce-for-japan' )
				),
				'default'     => '',
				'desc_tip'    => true,
			),
			'test_api_public_key' => array(
				'title'       => __( 'Test API Public Key', 'woocommerce-for-japan' ),
				'type'        => 'text',
				// Test API Public Key.
				'description' => sprintf(
					/* translators: %s: Enter Key. */
					__( 'Please enter %s from Paidy Admin site.', 'woocommerce-for-japan' ),
					__( 'Test API Public Key', 'woocommerce-for-japan' )
				),
				'default'     => '',
				'desc_tip'    => true,
			),
			'test_api_secret_key' => array(
				'title'       => __( 'Test API Secret Key', 'woocommerce-for-japan' ),
				'type'        => 'password',
				// Test API Secret Key.
				'description' => sprintf(
					/* translators: %s: Enter Key. */
					__( 'Please enter %s from Paidy Admin site.', 'woocommerce-for-japan' ),
					__( 'Test API Secret Key', 'woocommerce-for-japan' )
				),
				'default'     => '',
				'desc_tip'    => true,
			),
			'store_name'          => array(
				'title'       => __( 'Store Name', 'woocommerce-for-japan' ),
				'type'        => 'text',
				'description' => __( 'This controls the store name which the user sees during paidy checkout.', 'woocommerce-for-japan' ),
				'default'     => get_bloginfo( 'name' ),
			),
			'logo_image_url'      => array(
				'title'       => __( 'Logo Image (168×168 recommend)', 'woocommerce-for-japan' ),
				'type'        => 'image',
				'description' => __( 'URL of a custom logo that can be displayed in the checkout application header. If no value is specified, the Paidy logo will be displayed.', 'woocommerce-for-japan' ),
				'default'     => '',
				'placeholder' => __( 'Optional', 'woocommerce-for-japan' ),
			),
			'debug'               => array(
				'title'       => __( 'Debug Mode', 'woocommerce-for-japan' ),
				'type'        => 'checkbox',
				'label'       => __( 'Enable Debug Mode', 'woocommerce-for-japan' ),
				'default'     => 'no',
				'description' => __( 'Save debug data using WooCommerce logging.', 'woocommerce-for-japan' ),
			),
			'notice_email'        => array(
				'title'       => __( 'Notice e-mail', 'woocommerce-for-japan' ),
				'type'        => 'text',
				'description' => __( 'Set an e-mail address to send an e-mail when an error occurs during connection with paidy.', 'woocommerce-for-japan' ),
				'default'     => get_option( 'admin_email' ),
			),
			'webhook'             => array(
				'title'       => __( 'About Webhook', 'woocommerce-for-japan' ),
				'type'        => 'title',
				'description' => __( 'The webhooks set in the Paidy management screen are as follows. <br />', 'woocommerce-for-japan' ) . '<strong>' . home_url() . '/wp-json/paidy/v1/order/</strong>',
			),
		);
	}

	/**
	 * UI - Payment page Description fields for Paidy Payment.
	 */
	public function payment_fields() {
		// Description of payment method from settings.
		?>
		<br />
		<a href="https://paidy.com/consumer" target="_blank" class="jp4wc-paidy-icon">
			<img src="<?php echo esc_url( WC_PAIDY_ASSETS_URL . 'images/paidy_checkout_2023_320x100.png' ); ?>" alt="Paidy 翌月まとめてお支払い" style="max-height: none; float: none;">
		</a>
		<br />
		<p class="jp4wc-paidy-description"><?php echo esc_html( $this->description ); ?></p>
		<br />
		<?php
		if ( empty( $this->paidy_description ) ) {
			$paidy_explanation = $this->paidy_explanation();
		} else {
			$paidy_explanation = $this->paidy_description;
		}
		echo wp_kses( force_balance_tags( $paidy_explanation ), $this->paidy_description_allowed_html() );
	}

	/**
	 * Allowed HTML tags for the Paidy description output.
	 *
	 * @since 2.9.15
	 *
	 * @return array Allowed HTML for wp_kses().
	 */
	private function paidy_description_allowed_html() {
		return array(
			'a'      => array(
				'href'   => array(),
				'target' => array(),
			),
			'br'     => array(),
			'strong' => array(),
			'b'      => array(),
			'div'    => array(),
			'ul'     => array(),
			'li'     => array(),
		);
	}

	/**
	 * Validate the Paidy description field on save.
	 *
	 * The wp_kses() function does not fix unbalanced tags, and a stray closing tag saved in
	 * this field escapes the payment box when the classic checkout payment
	 * fragment is re-rendered, leaving an orphaned place-order row behind on
	 * every update_order_review call (duplicated order buttons). Balance the
	 * tags before saving so broken markup never reaches the checkout.
	 *
	 * @since 2.9.15
	 *
	 * @param string      $key   Field key.
	 * @param string|null $value Posted value.
	 * @return string Sanitized value with balanced tags.
	 */
	public function validate_paidy_description_field( $key, $value ) {
		$value = is_null( $value ) ? '' : trim( wp_unslash( $value ) );
		return wp_kses( force_balance_tags( $value ), $this->paidy_description_allowed_html() );
	}

	/**
	 * Provides the explanation for Paidy payment method.
	 *
	 * @return string HTML content explaining Paidy payment method.
	 */
	protected function paidy_explanation() {
		$image_url    = WC_PAIDY_ASSETS_URL . 'images/paidy_checkout_2023_320x100.png';
		$explain_html = '
        <div class="jp4wc-paidy-explanation">
		<img src="' . esc_url( $image_url ) . '" alt="Paidy 翌月まとめてお支払い" style="max-height: none; float: none;">
        <ul>
            <li style="list-style: disc !important;">クレジットカード、事前登録不要。</li>
            <li style="list-style: disc !important;">メールアドレスと携帯番号だけで、今すぐお買い物。</li>
            <li style="list-style: disc !important;">1か月に何度お買い物しても、お支払いは翌月まとめて1回でOK。</li>
            <li style="list-style: disc !important;">お支払いは翌月10日までに、コンビニ払い・銀行振込・口座振替で。</li>
        </ul>
        さらにペイディアプリから本人確認をすると、分割手数料無料*の３回あと払い**や、使い過ぎを防止する予算設定など、便利な機能をご利用いただけます。<br />
*銀行振込・口座振替のみ無料<br />
**1回のご利用金額が3,000円以上の場合のみ利用可能<br />
        Paidyについて詳しくは<a href="https://paidy.com/payments/" target="_blank">こちら</a>。
        </div>
        ';
		return apply_filters( 'jp4wc_paidy_explanation', $explain_html );
	}
	/**
	 * Process the payment and return the result
	 *
	 * @param int $order_id Order ID.
	 */
	public function process_payment( $order_id ) {
		$order = wc_get_order( $order_id );
		// Return thankyou redirect.
		return array(
			'result'   => 'success',
			'redirect' => $order->get_checkout_payment_url( true ),
		);
	}

	/**
	 * Make Paidy JavaScript for payment process
	 *
	 * @param string $order_id Order ID.
	 */
	public function paidy_make_order( $order_id ) {
		// Set Order.
		$order = wc_get_order( $order_id );
		// Set public key by environment.
		if ( 'live' === $this->environment ) {
			$api_public_key = $this->api_public_key;
		} else {
			$api_public_key = $this->test_api_public_key;
		}
		// Set logo image url.
		if ( isset( $this->logo_image_url ) ) {
			$logo_image_url = wp_get_attachment_url( $this->logo_image_url );
		} else {
			$logo_image_url = 'http://www.paidy.com/images/logo.png';
		}
		$date            = new DateTime();
		$paidy_order_ref = $order_id;
		// Set user id.
		if ( is_user_logged_in() ) {
			$user_id = get_current_user_id();
		} else {
			$user_id = 'guest-paidy' . $paidy_order_ref;
		}

		$jp4wc_countries = new WC_Countries();
		$states          = $jp4wc_countries->get_states();

		// Get products and coupons information from order.
		// Build the items as an array and print them with wp_json_encode() below:
		// concatenating JavaScript by hand printed a stray "}," for a skipped
		// entry (a zero-discount coupon such as a free-shipping coupon, or a line
		// item without a product), and a fee name with a newline or backslash
		// broke the string literal, so Paidy Checkout could not start (#232).
		$order_items  = apply_filters( 'jp4wc_paidy_order_items', $order->get_items( 'line_item' ) );
		$fees         = $order->get_fees();
		$items        = array();
		$paidy_amount = 0;
		foreach ( $order_items as $item ) {
			if ( $item->get_product_id() ) {
				$unit_price    = round( $item->get_subtotal() / $item->get_quantity(), 0 );
				$items[]       = array(
					'id'         => (string) $item->get_product_id(),
					'quantity'   => (int) $item->get_quantity(),
					'title'      => $item->get_name(),
					'unit_price' => (float) $unit_price,
				);
				$paidy_amount += $item->get_quantity() * $unit_price;
			}
		}
		$order_coupons = apply_filters( 'jp4wc_paidy_order_coupons', $order->get_items( 'coupon' ) );
		foreach ( $order_coupons as $coupon ) {
			// Compare as a number: a discount saved as the string "0.00" (e.g. through
			// the REST API) is truthy.
			if ( 0.0 !== (float) $coupon->get_discount() ) {
				$items[]       = array(
					'id'         => $coupon->get_code(),
					'quantity'   => 1,
					'title'      => $coupon->get_name(),
					'unit_price' => - (float) $coupon->get_discount(),
				);
				$paidy_amount -= $coupon->get_discount();
			}
		}

		$i = 1;
		foreach ( $fees as $fee ) {
			$items[]       = array(
				'id'         => 'fee' . $i,
				'quantity'   => 1,
				'title'      => $fee->get_name(),
				'unit_price' => (float) $fee->get_amount(),
			);
			$paidy_amount += intval( $fee->get_amount() );
			++$i;
		}

		// The JSON_HEX_* flags turn "<", ">", "&", "'" and '"' inside the values
		// into \u escapes, so a name cannot close the inline script.
		$items_json = wp_json_encode( $items, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT );
		if ( false === $items_json ) {
			$items_json = '[]';
		}

		// Check the order only for virtual products.
		$not_virtual = false;

		foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
			// Check if there are non-virtual products.
			if ( ! $cart_item['data']->is_virtual() ) {
				$not_virtual = true;
			}
		}
		// Set shipping address.
		if ( $not_virtual ) {
			if ( $order->get_shipping_postcode() ) {
				$shipping_address['line1'] = $order->get_shipping_address_2();
				$shipping_address['line2'] = $order->get_shipping_address_1();
				$shipping_address['city']  = $order->get_shipping_city();
				$shipping_address['state'] = $states['JP'][ $order->get_shipping_state() ];
				$shipping_address['zip']   = $order->get_shipping_postcode();
			} else {
				$shipping_address['line1'] = $order->get_billing_address_2();
				$shipping_address['line2'] = $order->get_billing_address_1();
				$shipping_address['city']  = $order->get_billing_city();
				$shipping_address['state'] = $states['JP'][ $order->get_billing_state() ];
				$shipping_address['zip']   = $order->get_billing_postcode();
			}
		}

		// Get the latest order. This page reloads on every retry of the
		// Paidy widget, so cache the per-customer risk-signal values
		// briefly — a few minutes of staleness doesn't affect the values
		// sent to Paidy below, but avoids refetching and re-hydrating the
		// customer's full completed-order history on every reload. Only
		// scalar values are cached (never WC_Order objects — they aren't
		// safe/meaningful to serialize into a transient).
		//
		// Guest checkouts have no numeric $user_id (it's 'guest-paidy' .
		// order ID here, not a real customer identity) — wc_get_orders()
		// would coerce that non-numeric string to customer_id 0, which
		// doesn't mean "this guest" but "no assigned customer", pulling in
		// unrelated guests' orders. There's no real order history to look
		// up for a guest, so skip the query entirely.
		if ( ! is_user_logged_in() ) {
			$order_history = array(
				'total_order_amount' => 0,
				'order_count'        => 0,
				'latest_order_total' => null,
				'latest_order_date'  => null,
			);
		} else {
			$order_history_cache_key = 'jp4wc_paidy_order_history_' . $user_id;
			$order_history           = get_transient( $order_history_cache_key );
		}
		if ( false === $order_history ) {
			$args   = array(
				'customer_id' => $user_id,
				'status'      => 'completed',
				'orderby'     => 'date',
				'order'       => 'DESC',
			);
			$orders = wc_get_orders( $args );

			$total_order_amount = 0;
			$order_count        = 0;
			$selected_orders    = array();
			foreach ( $orders as $each_order ) {
				if ( $each_order->get_payment_method() !== $this->id ) {
					$selected_orders[]   = $each_order;
					$total_order_amount += $each_order->get_total();
					++$order_count;
				}
			}
			if ( isset( $selected_orders[1] ) ) {
				$latest_order = end( $selected_orders );
			} elseif ( isset( $selected_orders[0] ) ) {
				$latest_order = $selected_orders[0];
			} else {
				$latest_order = null;
			}
			if ( isset( $latest_order ) ) {
				$latest_order_total = $latest_order->get_total();
				$latest_order_date  = $latest_order->get_date_created()->date( 'Y-m-d H:i:s' );
			} else {
				$latest_order_total = null;
				$latest_order_date  = null;
			}

			$order_history = array(
				'total_order_amount' => $total_order_amount,
				'order_count'        => $order_count,
				'latest_order_total' => $latest_order_total,
				'latest_order_date'  => $latest_order_date,
			);
			set_transient( $order_history_cache_key, $order_history, 5 * MINUTE_IN_SECONDS );
		}
		$total_order_amount = $order_history['total_order_amount'];
		$order_count        = $order_history['order_count'];

		if ( null !== $order_history['latest_order_date'] ) {
			$last_order_amount = $order_history['latest_order_total'];
			$day1              = strtotime( $order_history['latest_order_date'] );
			$day2              = strtotime( date_i18n( 'Y-m-d H:i:s' ) );
			$diff_day          = floor( ( $day2 - $day1 ) / ( 60 * 60 * 24 ) );
			if ( $diff_day <= 0 ) {
				$diff_day = 0;
			}
		} else {
			$last_order_amount = 0;
			$diff_day          = 0;
		}
		$order_amount = $order->get_total();
		$tax          = $order_amount - $paidy_amount - $order->get_shipping_total();

		if ( 'yes' === $this->enabled && isset( $api_public_key ) && '' !== $api_public_key && 'pending' === $order->get_status() ) :
			?>
			<script type="text/javascript">
				// Paidy Payment apply
				jQuery(window).on('load', function(){
					paidyPay();
				})
				var config = {
					"api_key": "<?php echo esc_js( $api_public_key ); ?>",
					"logo_url": "<?php echo esc_url( $logo_image_url ); ?>",
					"closed": function(callbackData) {
						/*
						Data returned in the callback:
						callbackData.id,
						callbackData.amount,
						callbackData.currency,
						callbackData.created_at,
						callbackData.status
						*/
						if(callbackData.status === "rejected"){
							window.location.href = "<?php echo esc_url( wc_get_checkout_url() . '?status=' ) . '" + callbackData.status + "&order_id=' . esc_js( $order_id ); ?>";
						}else if(callbackData.status === "authorized"){
							window.location.href = "<?php echo esc_url( $this->get_return_url( $order ) ) . '&transaction_id='; ?>" + callbackData.id;
						}else{
							window.location.href = "<?php echo esc_url( wc_get_checkout_url() ) . '?status='; ?>" + callbackData.status + "&order_id=<?php echo esc_js( $order_id ); ?>";
						}
					}
				};
				var paidyHandler = Paidy.configure(config);
				function paidyPay() {
					var payload = {
						"amount": <?php echo esc_js( $order_amount ); ?>,
						"currency": "JPY",
						"store_name": "<?php echo esc_js( $this->store_name ); ?>",
						"buyer": {
							"email": "<?php echo esc_js( $order->get_billing_email() ); ?>",
							"name1": "<?php echo esc_js( $order->get_billing_last_name() . ' ' . $order->get_billing_first_name() ); ?>",
			<?php
			$billing_yomigana_last_name = $order->get_meta( '_billing_yomigana_last_name' );
			if ( isset( $billing_yomigana_last_name ) ) :
				?>
							"name2": "<?php echo esc_js( $order->get_meta( '_billing_yomigana_last_name' ) . ' ' . $order->get_meta( '_billing_yomigana_first_name' ) ); ?>",
<?php endif; ?>
							"phone": "<?php echo esc_js( $order->get_billing_phone() ); ?>"
						},
						"buyer_data": {
							"user_id": "<?php echo esc_js( $user_id ); ?>",
							"order_count": <?php echo esc_js( $order_count ); ?>,
							"ltv": <?php echo esc_js( $total_order_amount ); ?>,
							"last_order_amount": <?php echo esc_js( $last_order_amount ); ?>,
							"last_order_at": <?php echo esc_js( $diff_day ); ?>
						},
						"order": {
							"items": <?php echo $items_json; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON from wp_json_encode() with the JSON_HEX_* flags above, safe inside an inline script. ?>,
							"order_ref": "<?php echo esc_js( $paidy_order_ref ); ?>",
					<?php
					if ( $not_virtual ) {
						echo '"shipping": ' . esc_js( $order->get_shipping_total() ) . ',';}
					?>
							"tax": <?php echo esc_js( $tax ); ?>
						},
						<?php if ( $not_virtual ) { ?>
						"shipping_address": {
							"line1": "<?php echo esc_js( $shipping_address['line1'] ); ?>",
							"line2": "<?php echo esc_js( $shipping_address['line2'] ); ?>",
							"city": "<?php echo esc_js( $shipping_address['city'] ); ?>",
							"state": "<?php echo esc_js( $shipping_address['state'] ); ?>",
							"zip": "<?php echo esc_js( $shipping_address['zip'] ); ?>"
						},
						<?php } ?>
						"description": "<?php echo esc_js( $this->store_name ); ?>",
						"metadata" : {"Platform" : "WooCommerce"}
					};
					paidyHandler.launch(payload);
				}
			</script>
				<?php elseif ( 'yes' === $this->enabled && isset( $api_public_key ) && '' === $api_public_key ) : ?>
			<h2><?php esc_html_e( 'This order has already been settled.', 'woocommerce-for-japan' ); ?></h2>
		<?php else : ?>
			<h2><?php echo esc_html_e( 'API Public key is not set. Please set an API public key in the admin page.', 'woocommerce-for-japan' ); ?></h2>
			<?php
			endif;
	}

	/**
	 * Set API key
	 *
	 * @return string $api_secret_key
	 */
	private function set_api_secret_key() {
		if ( 'live' === $this->environment ) {
			$api_secret_key = $this->api_secret_key;
		} else {
			$api_secret_key = $this->test_api_secret_key;
		}
		return $api_secret_key;
	}

	/**
	 * Load Paidy Token javascript
	 */
	public function paidy_token_scripts_method() {
		if ( is_checkout_pay_page() ) {
			// Image upload.
			wp_enqueue_media();

			wp_enqueue_script(
				'paidy-redirect',
				WC_PAIDY_ASSETS_URL . 'js/jp4wc-paidy.js',
				array(),
				WC_PAIDY_VERSION,
				true
			);
			$paygent_token_js_link = 'https://apps.paidy.com/';
			if ( is_checkout() ) {
				wp_enqueue_script(
					'paidy-token',
					$paygent_token_js_link,
					array(),
					WC_PAIDY_VERSION,
					false
				);
				// Paidy Payment for Checkout page.
				wp_register_style(
					'jp4wc-paidy',
					WC_PAIDY_ASSETS_URL . 'css/jp4wc-paidy.css',
					false,
					WC_PAIDY_VERSION
				);
				wp_enqueue_style( 'jp4wc-paidy' );
			}
		}
	}

	/**
	 * Load Paidy javascript for Admin
	 *
	 * @param string $hook_suffix Hook suffix.
	 */
	public function paidy_admin_enqueue_scripts( $hook_suffix ) {
		$screen = get_current_screen();
		if ( 'woocommerce_page_wc-settings' !== $hook_suffix ) {
			return;
		}
		// Image upload.
		wp_enqueue_media();
		if ( is_admin() && false === wp_script_is( 'wc-gateway-ppec-settings' ) && isset( $_GET['section'] ) && 'paidy' === $_GET['section'] ) {// phpcs:ignore
			wp_enqueue_script(
				'wc-gateway-paidy-settings',
				WC_PAIDY_ASSETS_URL . 'js/wc-gateway-paidy-settings.js',
				array( 'jquery' ),
				WC_PAIDY_VERSION,
				true
			);
		}
	}

	/**
	 * Update Cancel from Auth to Paidy System
	 *
	 * @param object $checkout WooCommerce Checkout object.
	 */
	public function checkout_reject_to_cancel( $checkout ) {
		if ( isset( $_GET['status'] ) ) { // phpcs:ignore
			if ( 'closed' === $_GET['status'] ) { // phpcs:ignore
				$message = __( 'Once the customer interrupted the payment.. Order ID:', 'woocommerce-for-japan' ) . $_GET['order_id'];// phpcs:ignore
				$this->jp4wc_framework->jp4wc_debug_log( $message, $this->debug, 'paidy-wc' );
				} elseif ( 'rejected' === $_GET['status'] || isset( $_GET['order_id'] ) ) {// phpcs:ignore
				$reject_message = __( 'This Paidy payment has been declined. Please select another payment method.', 'woocommerce-for-japan' );
				wc_add_notice( $reject_message, 'error' );
			}
		}
	}

	/**
	 * Update Complete at thank you page for Paidy Payment
	 *
	 * @param string $order_id Order ID.
	 */
	public function thankyou_completed( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		$current_status = $order->get_status();
		// Idempotency: skip if payment_complete() was already called (transaction_id already set).
		if ( ( 'pending' === $current_status || 'cancelled' === $current_status ) && empty( $order->get_transaction_id() ) ) {
			$transaction_id = isset( $_GET['transaction_id'] ) ? sanitize_text_field( wp_unslash( $_GET['transaction_id'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

			// Verify the payment with Paidy server-side before completing the order. The
			// transaction id comes from the (buyer-controllable) return URL, so it must not
			// be trusted on its own: confirm the payment belongs to this order, is authorized,
			// and matches the order total before reducing stock and completing payment.
			if ( ! $this->paidy_verify_payment_for_order( $order, $transaction_id ) ) {
				$this->jp4wc_framework->jp4wc_debug_log(
					'Paidy thank-you completion blocked: payment verification failed for order ' . $order_id,
					$this->debug,
					'paidy-wc'
				);
				return;
			}

			// Reduce stock levels.
			wc_reduce_stock_levels( $order_id );
			$order->payment_complete( $transaction_id );
			$message  = __( 'Paidy Payment succeeds to authorize and move to thank you page. Get data is following.', 'woocommerce-for-japan' ) . "\n";
			$message .= $this->jp4wc_framework->jp4wc_array_to_message( $_GET ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$this->jp4wc_framework->jp4wc_debug_log( $message, $this->debug, 'paidy-wc' );
		}
	}

	/**
	 * Validate api_public_key input and add error
	 *
	 * @param string $key not use.
	 * @param string $value API Public Key.
	 * @return mixed
	 */
	public function validate_api_public_key_field( $key, $value ) {
		return $this->setting_required_field( __( 'API Public Key', 'woocommerce-for-japan' ), __( 'Production environment', 'woocommerce-for-japan' ), $value );
	}

	/**
	 * Validate api_secret_key input and add error
	 *
	 * @param string $key not use.
	 * @param string $value API Secret Key.
	 * @return mixed
	 */
	public function validate_api_secret_key_field( $key, $value ) {
		return $this->setting_required_field( __( 'API Secret Key', 'woocommerce-for-japan' ), __( 'Production environment', 'woocommerce-for-japan' ), $value );
	}

	/**
	 * Validate api_public_key input and add error
	 *
	 * @param string $title Field title.
	 * @param string $environment Environment.
	 * @param string $value API Public Key.
	 * @return mixed
	 */
	public function setting_required_field( $title, $environment, $value ) {
		if ( isset( $value ) && 1 > strlen( $value ) ) {
			$paidy_link = 'https://campaign.paidy.com/woocommerce';
			/* translators: 1) Field title 2) Environment 3) Paidy PR link */
			WC_Admin_Settings::add_error( sprintf( __( 'If you do not set %1$s, it will not work in the %2$s. Application is necessary for acquisition.', 'woocommerce-for-japan' ), $title, $environment, $paidy_link ) );
		}

		return $value;
	}

	/**
	 * Update Cancel from Auth to Paidy System
	 *
	 * @param string $order_id Order ID.
	 */
	public function paidy_order_paidy_status_processing_to_cancelled( $order_id ) {
		$secret_key           = $this->set_api_secret_key();
		$order                = wc_get_order( $order_id );
		$order_payment_method = $order->get_payment_method();
		$transaction_id       = $order->get_transaction_id();
		if ( $order_payment_method === $this->id && ! empty( $transaction_id ) ) {
			$send_url = $this->paidy_payment_api_url( $transaction_id, 'close' );
			if ( null === $send_url ) {
				$order->add_order_note( $this->paidy_invalid_payment_id_message() );
				return false;
			}
			$args = array(
				'method'  => 'POST',
				'body'    => '{}',
				'headers' => array(
					'Content-Type'  => 'application/json',
					'Paidy-Version' => '2018-04-10',
					'Authorization' => 'Bearer ' . $secret_key,
				),
			);

			$message = 'Send URL is following. : ' . $send_url;
			$this->jp4wc_framework->jp4wc_debug_log( $message, $this->debug, 'paidy-wc' );

			$close = wp_remote_post( $send_url, $args );
			if ( is_wp_error( $close ) ) {
				$order->add_order_note( $close->get_error_message() );
				return false;
			}
			$http_code   = (int) wp_remote_retrieve_response_code( $close );
			$close_array = json_decode( wp_remote_retrieve_body( $close ), true );
			if ( $this->paidy_is_closed_response( $http_code, $close_array ) ) {
				$message = $this->jp4wc_framework->jp4wc_array_to_message( $close_array ) . __( 'This order is success cancellation data at Paidy.', 'woocommerce-for-japan' );
				$this->jp4wc_framework->jp4wc_debug_log( $message, $this->debug, 'paidy-wc' );
			} else {
				$message = $this->jp4wc_framework->jp4wc_array_to_message( $close_array ) . __( 'This order is already close data at Paidy.', 'woocommerce-for-japan' ) . ' HTTP:' . $http_code;
				$this->jp4wc_framework->jp4wc_debug_log( $message, $this->debug, 'paidy-wc' );

				$order->add_order_note( __( 'Cancelled processing has not been completed due to a Paidy error. Please check Paidy admin.', 'woocommerce-for-japan' ) . ' (HTTP ' . $http_code . ')' );
				return false;
			}
		}
		return true;
	}

	/**
	 * Refund at Paidy what is left of a completed order when it is cancelled.
	 *
	 * The refund goes through wc_create_refund(), so WooCommerce records it and only the
	 * amount not refunded yet is sent. The order stays cancelled even when this refunds it
	 * in full. Versions before 2.9.17 refunded the order total at Paidy without recording a
	 * refund in WooCommerce; such an order is not refunded again.
	 *
	 * @param int $order_id Order ID.
	 */
	public function paidy_order_paidy_status_completed_to_cancelled( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order || $this->id !== $order->get_payment_method() ) {
			return;
		}
		// Every Paidy refund since 2.9.17 has a WooCommerce refund sent through the gateway,
		// and earlier versions blocked the refund on cancellation once anything had been
		// refunded at Paidy. A Paidy refund ID without such a refund is therefore an earlier
		// version's refund on cancellation, which refunded the order total.
		$gateway_refunds = array_filter(
			$order->get_refunds(),
			static function ( $refund ) {
				return $refund->get_refunded_payment();
			}
		);
		if ( $order->get_meta( 'paidy_refund_id' ) && empty( $gateway_refunds ) ) {
			return;
		}
		$amount = $order->get_remaining_refund_amount();
		if ( 0 >= (float) $amount ) {
			return;
		}

		// WooCommerce marks an order it refunds in full as refunded; keep the status the shop chose.
		$keep_status = static function ( $status, $refunded_order_id ) use ( $order_id ) {
			return (int) $refunded_order_id === (int) $order_id ? false : $status;
		};
		add_filter( 'woocommerce_order_fully_refunded_status', $keep_status, PHP_INT_MAX, 2 );
		try {
			$refund = wc_create_refund(
				array(
					'order_id'       => $order_id,
					'amount'         => $amount,
					'refund_payment' => true,
					// WooCommerce puts the items back in stock when the order is cancelled.
					'restock_items'  => false,
				)
			);
		} finally {
			remove_filter( 'woocommerce_order_fully_refunded_status', $keep_status, PHP_INT_MAX );
		}

		if ( is_wp_error( $refund ) ) {
			$order->add_order_note( __( 'The remaining amount was not refunded at Paidy when the order was cancelled. Please check Paidy admin.', 'woocommerce-for-japan' ) . ' (' . $refund->get_error_message() . ')' );
		}
	}
	/**
	 * Remove the refund button for orders with status 'processing'.
	 */
	public function paidy_remove_refund_button_for_processing() {
		global $post;
		if ( ! $post || 'shop_order' !== get_post_type( $post->ID ) ) {
			if ( isset($_GET['id']) && 'shop_order' === get_post_type( $_GET['id'] ) ) { // phpcs:ignore
				$order_id = intval( $_GET['id'] ); // phpcs:ignore
			} else {
				return;
			}
		}

		if ( ! isset( $order_id ) ) {
			$order_id = $post->ID;
		}
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}

		// Check if the payment method is Paidy.
		if ( $this->id !== $order->get_payment_method() ) {
			return;
		}

		if ( 'processing' === $order->get_status() ) :
			?>
			<script>
			jQuery(document).ready(function($){
				$('.refund-items').remove();
			});
			</script>
			<?php
			endif;
	}

	/**
	 * Update Sale from Auth to Paidy System
	 *
	 * @param string $order_id Order ID.
	 *
	 * @return boolean true or false
	 */
	public function jp4wc_order_paidy_status_completed( $order_id ) {
		$secret_key           = $this->set_api_secret_key();
		$order                = wc_get_order( $order_id );
		$order_payment_method = $order->get_payment_method();
		if ( $order_payment_method === $this->id ) {
			// Prevent duplicate capture calls when the action fires multiple times
			// (e.g. when WooCommerce instantiates the gateway class more than once).
			if ( $order->get_meta( 'paidy_capture_id' ) ) {
				return;
			}
			$transaction_id = $order->get_transaction_id();
			$situation      = __( 'Status Change from Processing to completed.', 'woocommerce-for-japan' );
			$send_url       = $this->paidy_payment_api_url( $transaction_id, 'captures' );
			if ( null === $send_url ) {
				$message = $this->paidy_invalid_payment_id_message();
				$order->add_order_note( $message );
				$this->send_notice_email( $this->notice_message( $order_id, $transaction_id, $situation, $message ) );
				return false;
			}
			$args = array(
				'method'  => 'POST',
				'body'    => '{"metadata": {"Platform": "WooCommerce"}}',
				'headers' => array(
					'Content-Type'  => 'application/json',
					'Paidy-Version' => '2018-04-10',
					'Authorization' => 'Bearer ' . $secret_key,
				),
			);
			if ( 'no' !== $this->debug ) {
				$debug_message = 'Send URL is following. : ' . $send_url;
				$this->jp4wc_framework->jp4wc_debug_log( $debug_message, true, 'paidy-wc' );
			}
			$capture = wp_remote_post( $send_url, $args );
			if ( is_wp_error( $capture ) ) {
				$http_code     = 0;
				$capture_array = null;
			} else {
				$http_code     = (int) wp_remote_retrieve_response_code( $capture );
				$capture_array = json_decode( wp_remote_retrieve_body( $capture ), true );
			}

			if ( $this->paidy_is_closed_response( $http_code, $capture_array ) ) {
				$message = $this->jp4wc_framework->jp4wc_array_to_message( $capture_array ) . __( 'This is capture data.', 'woocommerce-for-japan' );
				$this->jp4wc_framework->jp4wc_debug_log( $message, $this->debug, 'paidy-wc' );

				if ( isset( $capture_array['captures'][0]['id'] ) ) {
					$order->update_meta_data( 'paidy_capture_id', $capture_array['captures'][0]['id'] );
					$order->save_meta_data();
				}
				if ( (float) $capture_array['amount'] === (float) $order->get_total() && $transaction_id === $capture_array['id'] ) {
					$order->add_order_note( __( 'In the payment completion process, the amount and ID match were confirmed.', 'woocommerce-for-japan' ) );
					return true;
				} else {
					$order->add_order_note( __( 'In the payment completion process, the amount and ID did not match. Check on the Paidy admin.', 'woocommerce-for-japan' ) );
				}
			} elseif ( is_wp_error( $capture ) ) {
				$message = $capture->get_error_message();
				$order->add_order_note( $message );
			} else {
				$message = $this->jp4wc_framework->jp4wc_array_to_message( $capture_array ) . __( 'This is capture data.', 'woocommerce-for-japan' );
				$this->jp4wc_framework->jp4wc_debug_log( $message, $this->debug, 'paidy-wc' );

				if ( isset( $capture_array['status'] ) ) {
					$this->paidy_check_response( $capture_array['status'], $order );
					if ( isset( $paidy_info ) && isset( $paidy_info['captures'] ) ) {
						return true;
					}
				} else {
					$order->add_order_note( __( 'There was no status in the notification from Paidy.', 'woocommerce-for-japan' ) . ' (HTTP ' . $http_code . ')' );
				}
			}
			$email_message = $this->notice_message( $order_id, $transaction_id, $situation, $message );
			$this->send_notice_email( $email_message );
			return false;
		}
		return true;
	}

	/**
	 * Check the response status from Paidy and add an order note if there is an error.
	 *
	 * @param string   $status The response status code.
	 * @param WC_Order $order The WooCommerce order object.
	 */
	public function paidy_check_response( $status, $order ) {
		if ( '403' === $status ) {// Forbidden.
			$message = __( 'You have made a forbidden request.', 'woocommerce-for-japan' ) . __( 'Please go to your Paidy dashboard and check.', 'woocommerce-for-japan' );
			$order->add_order_note( $message );
		} elseif ( '401' === $status ) {// Unauthorized.
			$message = __( 'You have made an unauthorized request.', 'woocommerce-for-japan' ) . __( 'Please go to your Paidy dashboard and check.', 'woocommerce-for-japan' );
			$order->add_order_note( $message );
		} elseif ( '409' === $status ) {// Conflict.
			$message = __( 'You have made a conflict request.', 'woocommerce-for-japan' ) . __( 'Please go to your Paidy dashboard and check.', 'woocommerce-for-japan' );
			$order->add_order_note( $message );
		} elseif ( '404' === $status ) {// Not Found.
			$message = __( 'The requested resource could not be found.', 'woocommerce-for-japan' ) . __( 'Please go to your Paidy dashboard and check.', 'woocommerce-for-japan' );
			$order->add_order_note( $message );
		} elseif ( '400' === $status ) {// Bad Request.
			$message = __( 'The request failed.', 'woocommerce-for-japan' ) . __( 'Please go to your Paidy dashboard and check.', 'woocommerce-for-japan' );
			$order->add_order_note( $message );
		} elseif ( '200' === $status ) {// Good Request.
			$order->add_order_note( __( 'I received a notification from Paidy and the status was successful.', 'woocommerce-for-japan' ) );
		} else {
			$order->add_order_note( __( 'I received a notification from Paidy stating that the status was unexpected.', 'woocommerce-for-japan' ) . ' Status:' . $status );
		}
	}

	/**
	 * Process a refund if supported
	 *
	 * @param  int    $order_id Order ID.
	 * @param  float  $amount Refund amount.
	 * @param  string $reason Refund reason.
	 * @return  boolean True or false based on success, or a WP_Error object
	 */
	public function process_refund( $order_id, $amount = null, $reason = '' ) {
		$secret_key           = $this->set_api_secret_key();
		$order                = wc_get_order( $order_id );
		$order_payment_method = $order->get_payment_method();
		$capture_id           = $order->get_meta( 'paidy_capture_id', true );
		if ( $order_payment_method === $this->id ) {
			$transaction_id = $order->get_transaction_id();
			$post_data      = '{"capture_id":"' . $capture_id . '","amount":"' . $amount . '","metadata" : {"Platform" : "WooCommerce"}}';
			$send_url       = $this->paidy_payment_api_url( $transaction_id, 'refunds' );
			$args           = array(
				'method'  => 'POST',
				'body'    => $post_data,
				'headers' => array(
					'Content-Type'  => 'application/json',
					'Paidy-Version' => '2018-04-10',
					'Authorization' => 'Bearer ' . $secret_key,
				),
			);
			// Debug message.
			$message  = 'Send URL is following. : ' . $send_url . "\n";
			$message .= 'Post data is following. : ' . $post_data;
			$this->jp4wc_framework->jp4wc_debug_log( $message, $this->debug, 'paidy-wc' );
			if ( '' === $capture_id ) {
				$order->add_order_note( __( 'Refund is not possible because Paidy has not completed processing.', 'woocommerce-for-japan' ) );
				return false;
			}
			if ( null === $send_url ) {
				$order->add_order_note( $this->paidy_invalid_payment_id_message() );
				return false;
			}
			$refund = wp_remote_post( $send_url, $args );
			if ( is_wp_error( $refund ) ) {
				$order->add_order_note( $refund->get_error_message() );
				return false;
			}
			$http_code    = (int) wp_remote_retrieve_response_code( $refund );
			$refund_array = json_decode( wp_remote_retrieve_body( $refund ), true );
			if ( $this->paidy_is_closed_response( $http_code, $refund_array ) ) {
				$order->update_meta_data( 'paidy_refund_id', $this->paidy_merge_refund_ids( $order->get_meta( 'paidy_refund_id' ), $refund_array ) );
				$order->save_meta_data();
				$order->add_order_note( __( 'Completion refunding has been completed at Paidy.', 'woocommerce-for-japan' ) );
				return true;
			}
			$message = $this->jp4wc_framework->jp4wc_array_to_message( $refund_array ) . __( 'This is refund data.', 'woocommerce-for-japan' ) . ' HTTP:' . $http_code;
			$this->jp4wc_framework->jp4wc_debug_log( $message, $this->debug, 'paidy-wc' );

			if ( isset( $refund_array['status'] ) ) {
				$this->paidy_check_response( $refund_array['status'], $order );
				if ( '403' === $refund_array['status'] ) {
					$paidy_info = $this->paidy_get_payment_data( $transaction_id );
					if ( isset( $paidy_info ) && isset( $paidy_info['refund'] ) ) {
						return true;
					}
				}
			} else {
				// A 5xx error page or an empty body is not a refund; reporting success here
				// would record a refund in WooCommerce that Paidy never made.
				$order->add_order_note( __( 'There was no status in the notification from Paidy.', 'woocommerce-for-japan' ) . ' (HTTP ' . $http_code . ')' );
			}
			return false;
		}
	}

	/**
	 * Build the Paidy API URL for a payment, or null when the ID is not a Paidy payment ID.
	 *
	 * Paidy only documents that payment IDs start with "pay_"; the IDs it actually issues use
	 * the base64url alphabet (letters, digits, "_" and "-", e.g. pay_aii8_kYAAEYA2BDW). "_" and
	 * "-" are RFC 3986 unreserved characters that rawurlencode() leaves untouched, so allowing
	 * them keeps the path/query injection protection intact: "/", "?", "#", "%" and whitespace
	 * are still rejected ("D" keeps "$" from matching before a trailing newline). Every request
	 * that carries the secret key goes through here, because an order's transaction ID is not
	 * guaranteed to be one Paidy issued: versions before 2.9.14 saved the thank-you URL
	 * parameter unverified, and the ID can be edited on the order screen.
	 *
	 * @since 2.9.17
	 *
	 * @param mixed  $payment_id Paidy payment ID.
	 * @param string $action     Sub-resource to append ("close", "captures" or "refunds"), or "".
	 * @return string|null API URL, or null when the payment ID is malformed.
	 */
	private function paidy_payment_api_url( $payment_id, $action = '' ) {
		if ( ! is_string( $payment_id ) || ! preg_match( '/^pay_[A-Za-z0-9_-]+$/D', $payment_id ) ) {
			return null;
		}
		$url = 'https://api.paidy.com/payments/' . rawurlencode( $payment_id );
		if ( '' !== $action ) {
			$url .= '/' . $action;
		}
		return $url;
	}

	/**
	 * Whether Paidy answered a close, capture or refund request with a closed payment.
	 *
	 * Anything else means the operation did not happen: a non-2xx status, a body that is not
	 * a JSON object (such as an HTML error page from a 5xx), or a payment in another state.
	 *
	 * @since 2.9.17
	 *
	 * @param int   $http_code HTTP status code of the response.
	 * @param mixed $body      Decoded JSON body of the response.
	 * @return bool
	 */
	private function paidy_is_closed_response( $http_code, $body ) {
		return $http_code >= 200 && $http_code < 300 && is_array( $body ) && isset( $body['status'] ) && 'closed' === $body['status'];
	}

	/**
	 * The refund IDs to save on an order after Paidy carried out a refund.
	 *
	 * Paidy answers a refund with the payment and all of its refunds, in an order it does
	 * not document, so every refund ID in the answer that is not saved yet is added,
	 * rather than the first one, which would be the earlier refund on a second refund.
	 *
	 * @since 2.9.17
	 *
	 * @param mixed $saved_ids Value of the order's paidy_refund_id meta.
	 * @param array $payment   Decoded Paidy payment from the refund answer.
	 * @return string[]
	 */
	private function paidy_merge_refund_ids( $saved_ids, $payment ) {
		if ( is_array( $saved_ids ) ) {
			$refund_ids = array_values( array_filter( $saved_ids, 'is_string' ) );
		} else {
			$refund_ids = is_string( $saved_ids ) && '' !== $saved_ids ? array( $saved_ids ) : array();
		}
		$refunds = isset( $payment['refunds'] ) && is_array( $payment['refunds'] ) ? $payment['refunds'] : array();
		foreach ( $refunds as $refund ) {
			if ( is_array( $refund ) && isset( $refund['id'] ) && is_string( $refund['id'] ) && ! in_array( $refund['id'], $refund_ids, true ) ) {
				$refund_ids[] = $refund['id'];
			}
		}

		return $refund_ids;
	}

	/**
	 * Order note for a transaction ID that is not sent to Paidy because it is malformed.
	 *
	 * @since 2.9.17
	 *
	 * @return string
	 */
	private function paidy_invalid_payment_id_message() {
		return __( 'The Paidy payment ID of this order is not in the expected format, so no request was sent to Paidy. Please check the transaction ID and your Paidy dashboard.', 'woocommerce-for-japan' );
	}

	/**
	 * Check Paidy payment details by payment_id
	 *
	 * @param string $payment_id Paidy payment ID.
	 * @return array|null Payment data array on success, null on any failure.
	 */
	public function paidy_get_payment_data( $payment_id ) {
		// $payment_id can come from the buyer-controllable thank-you URL transaction_id param.
		$send_url = $this->paidy_payment_api_url( $payment_id );
		if ( null === $send_url ) {
			$this->jp4wc_framework->jp4wc_debug_log(
				'Paidy get payment data: invalid payment_id format: ' . ( is_string( $payment_id ) ? $payment_id : gettype( $payment_id ) ),
				$this->debug,
				'paidy-wc'
			);
			return null;
		}
		$args     = array(
			'headers' => array(
				'Content-Type'  => 'application/json',
				'Paidy-Version' => '2018-04-10',
				'Authorization' => 'Bearer ' . $this->set_api_secret_key(),
			),
		);
		$response = wp_safe_remote_get( $send_url, $args );
		if ( is_wp_error( $response ) ) {
			$this->jp4wc_framework->jp4wc_debug_log(
				'Paidy get payment data request failed: ' . $response->get_error_message(),
				$this->debug,
				'paidy-wc'
			);
			return null;
		}
		$http_code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== (int) $http_code ) {
			$this->jp4wc_framework->jp4wc_debug_log(
				'Paidy get payment data returned HTTP ' . $http_code . ' for payment ' . $payment_id,
				$this->debug,
				'paidy-wc'
			);
			return null;
		}
		$decoded = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $decoded ) ) {
			$this->jp4wc_framework->jp4wc_debug_log(
				'Paidy get payment data: invalid JSON response for payment ' . $payment_id,
				$this->debug,
				'paidy-wc'
			);
			return null;
		}
		return $decoded;
	}

	/**
	 * Verify a Paidy payment server-side before completing an order.
	 *
	 * Queries the Paidy API for the given payment and confirms that it belongs to
	 * the supplied order, is in an authorized/active state, and that its amount
	 * matches the order total. This prevents an order from being marked paid on the
	 * strength of an attacker-supplied transaction id (thank-you page) or webhook
	 * body alone, which would otherwise allow goods to ship without a real payment.
	 *
	 * @param WC_Order|false $order          The order to verify against.
	 * @param string         $transaction_id Paidy payment ID.
	 * @return bool True when the payment is verified for this order, false otherwise.
	 */
	public function paidy_verify_payment_for_order( $order, $transaction_id ) {
		if ( ! $order instanceof WC_Order || empty( $transaction_id ) ) {
			return false;
		}

		$paidy_info = $this->paidy_get_payment_data( $transaction_id );

		if ( ! is_array( $paidy_info ) || empty( $paidy_info['status'] ) ) {
			$this->jp4wc_framework->jp4wc_debug_log(
				'Paidy payment verification failed: no payment data for transaction ' . $transaction_id,
				$this->debug,
				'paidy-wc'
			);
			return false;
		}

		// The payment id returned by Paidy must match the one we queried.
		if ( isset( $paidy_info['id'] ) && (string) $paidy_info['id'] !== (string) $transaction_id ) {
			$this->jp4wc_framework->jp4wc_debug_log(
				'Paidy payment verification failed: payment id mismatch for transaction ' . $transaction_id,
				$this->debug,
				'paidy-wc'
			);
			return false;
		}

		// The payment must reference this exact order.
		$order_ref = isset( $paidy_info['order']['order_ref'] ) ? (string) $paidy_info['order']['order_ref'] : '';
		if ( (string) $order->get_id() !== $order_ref ) {
			$this->jp4wc_framework->jp4wc_debug_log(
				'Paidy payment verification failed: order_ref mismatch (expected ' . $order->get_id() . ', got ' . $order_ref . ')',
				$this->debug,
				'paidy-wc'
			);
			return false;
		}

		// The authorized amount must match the order total.
		$paid_amount  = isset( $paidy_info['amount'] ) ? (float) $paidy_info['amount'] : -1.0;
		$order_amount = (float) $order->get_total();
		if ( abs( $paid_amount - $order_amount ) >= 0.01 ) {
			$this->jp4wc_framework->jp4wc_debug_log(
				'Paidy payment verification failed: amount mismatch (expected ' . $order_amount . ', got ' . $paid_amount . ')',
				$this->debug,
				'paidy-wc'
			);
			return false;
		}

		// The payment must be in an authorized/active state. Filterable to allow
		// for capture flows where the payment has already moved to "closed".
		$allowed_statuses = apply_filters(
			'paidy_verify_allowed_statuses',
			array( 'authorized', 'active', 'closed' ),
			$order
		);
		if ( ! is_array( $allowed_statuses ) ) {
			$allowed_statuses = array( 'authorized', 'active', 'closed' );
		}
		if ( ! in_array( $paidy_info['status'], $allowed_statuses, true ) ) {
			$this->jp4wc_framework->jp4wc_debug_log(
				'Paidy payment verification failed: unexpected status "' . $paidy_info['status'] . '" for transaction ' . $transaction_id,
				$this->debug,
				'paidy-wc'
			);
			return false;
		}

		return true;
	}

	/**
	 * Send notice e-mail to shop owner
	 *
	 * @param  string $message Error message.
	 */
	public function send_notice_email( $message ) {
		$to = $this->notice_email;
		if ( is_email( $to ) ) {
			$subject = __( '[WooCommerce] Notice of error occurrence in Paidy payment linkage', 'woocommerce-for-japan' );
			$headers = array( 'Content-Type: text/html; charset=UTF-8' );
			wp_mail( $to, $subject, $message, $headers );
		}
	}

	/**
	 * Send notice e-mail to shop owner
	 *
	 * @param  string $order_id Order ID.
	 * @param  string $transaction_id Paidy payment ID.
	 * @param  string $situation Error situation.
	 * @param  string $error_message Error message.
	 * @return string
	 */
	public function notice_message( $order_id, $transaction_id, $situation, $error_message = null ) {
		$message  = '';
		$message .= __( 'An error has occurred in the Paidy payment linkage when changing the status of WooCommerce.', 'woocommerce-for-japan' ) . "\n";
		$message .= __( 'Please check the status of Paidy payment and respond accordingly.', 'woocommerce-for-japan' ) . "\n\n";
		$message .= __( 'Order number:', 'woocommerce-for-japan' ) . $order_id . "\n";
		$message .= __( 'Order details URL:', 'woocommerce-for-japan' ) . site_url() . '/wp-admin/post.php?post=' . $order_id . '&action=edit' . "\n";
		$message .= __( 'Paidy payment ID:', 'woocommerce-for-japan' ) . $transaction_id . "\n";
		$message .= __( 'Error occurrence time:', 'woocommerce-for-japan' ) . gmdate( 'Y/m/d H:i:s' ) . "\n";
		$message .= __( 'Error situation:', 'woocommerce-for-japan' ) . $situation . "\n";
		if ( isset( $error_message ) ) {
			$message .= __( 'Error situation:', 'woocommerce-for-japan' ) . $error_message . "\n";
		}
		$message .= "\n" . __( '* This e-mail is for sending only, so you cannot reply directly to this e-mail.', 'woocommerce-for-japan' );
		return $message;
	}

	/**
	 * Generate Image HTML.
	 *
	 * @param  mixed $key Key.
	 * @param  mixed $data Data.
	 * @since  1.5.0
	 * @return string
	 */
	public function generate_image_html( $key, $data ) {
		$field_key = $this->get_field_key( $key );
		$defaults  = array(
			'title'             => '',
			'disabled'          => false,
			'class'             => '',
			'css'               => '',
			'placeholder'       => '',
			'type'              => 'text',
			'desc_tip'          => false,
			'description'       => '',
			'custom_attributes' => array(),
		);

		$data  = wp_parse_args( $data, $defaults );
		$value = $this->get_option( $key );

		// Hide show add remove buttons.
		$maybe_hide_add_style    = '';
		$maybe_hide_remove_style = '';

		// For backwards compatibility (customers that already have set a url).
		$value_is_url = filter_var( $value, FILTER_VALIDATE_URL ) !== false;

		if ( empty( $value ) || $value_is_url ) {
			$maybe_hide_remove_style = 'display: none;';
		} else {
			$maybe_hide_add_style = 'display: none;';
		}

		ob_start();
		?>
		<tr>
			<th scope="row" class="titledesc">
				<label for="<?php echo esc_attr( $field_key ); ?>"><?php echo wp_kses_post( $data['title'] ); ?> <?php echo esc_html( $this->get_tooltip_html( $data ) ); ?></label>
			</th>

			<td class="image-component-wrapper">
				<div class="image-preview-wrapper">
				<?php
				if ( ! $value_is_url ) {
					echo wp_get_attachment_image( $value, 'thumbnail' );
				} else {
					// translators: %s: URL of the image.
					printf( esc_html__( 'Already using URL as image: %s', 'woocommerce-for-japan' ), esc_url( $value ) );
				}
				?>
				</div>

				<button
						class="button image_upload"
						data-field-id="<?php echo esc_attr( $field_key ); ?>"
						data-media-frame-title="<?php echo esc_attr( __( 'Select a image to upload', 'woocommerce-for-japan' ) ); ?>"
						data-media-frame-button="<?php echo esc_attr( __( 'Use this image', 'woocommerce-for-japan' ) ); ?>"
						data-add-image-text="<?php echo esc_attr( __( 'Add image', 'woocommerce-for-japan' ) ); ?>"
						style="<?php echo esc_attr( $maybe_hide_add_style ); ?>"
				>
					<?php echo esc_html__( 'Add image', 'woocommerce-for-japan' ); ?>
				</button>

				<button
						class="button image_remove"
						data-field-id="<?php echo esc_attr( $field_key ); ?>"
						style="<?php echo esc_attr( $maybe_hide_remove_style ); ?>"
				>
					<?php echo esc_html__( 'Remove image', 'woocommerce-for-japan' ); ?>
				</button>

				<input type="hidden"
						name="<?php echo esc_attr( $field_key ); ?>"
						id="<?php echo esc_attr( $field_key ); ?>"
						value="<?php echo esc_attr( $value ); ?>"
				/>
			</td>
		</tr>
			<?php

			return ob_get_clean();
	}
}
