<?php
/**
 * WooCommerce At Store Payment Gateway Blocks Support
 *
 * @package Japanized_For_WooCommerce
 * @version 1.2.0
 */

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'AbstractPaymentMethodType' ) ) {
	return;
}

/**
 * WC_Gateway_AtStore_JP_Blocks_Support class.
 *
 * @extends AbstractPaymentMethodType
 */
final class WC_Payments_AtStore_Blocks_Support extends AbstractPaymentMethodType {
	/**
	 * The gateway instance.
	 *
	 * @var WC_Gateway_AtStore_JP
	 */
	private $gateway;

	/**
	 * Payment method name/id/slug.
	 *
	 * @var string
	 */
	protected $name = 'atstore';

	/**
	 * Initializes the payment method type.
	 */
	public function initialize() {
		$this->settings = get_option( 'woocommerce_atstore_settings', array() );
		$gateways       = WC()->payment_gateways->payment_gateways();
		$this->gateway  = $gateways[ $this->name ];
	}

	/**
	 * Returns if this payment method should be active. If false, the scripts will not be enqueued.
	 *
	 * @return boolean
	 */
	public function is_active() {
		return $this->gateway->is_available();
	}

	/**
	 * Returns an array of scripts/handles to be registered for this payment method.
	 *
	 * @return array
	 */
	public function get_payment_method_script_handles() {
		$script_path       = '/assets/js/build/frontend/blocks/atstore.js';
		$script_asset_path = JP4WC_ABSPATH . 'assets/js/build/frontend/blocks/atstore.asset.php';
		$script_asset      = file_exists( $script_asset_path )
			? require $script_asset_path
			: array(
				'dependencies' => array(),
				'version'      => '1.2.0',
			);
		$script_url        = JP4WC_URL_PATH . $script_path;

		wp_register_script(
			'wc-atstore-payments-blocks',
			$script_url,
			$script_asset['dependencies'],
			$script_asset['version'],
			true
		);

		if ( function_exists( 'wp_set_script_translations' ) ) {
			wp_set_script_translations( 'wc-atstore-payments-blocks', 'woocommerce-for-japan', JP4WC_ABSPATH . 'i18n/' );
		}

		return array( 'wc-atstore-payments-blocks' );
	}

	/**
	 * Returns an array of key=>value pairs of data made available to the payment methods script.
	 *
	 * @return array
	 */
	public function get_payment_method_data() {
		return array(
			'title'       => $this->get_setting( 'title' ),
			'description' => $this->get_setting( 'description' ),
			'supports'    => array_filter( $this->gateway->supports, array( $this->gateway, 'supports' ) ),
		);
	}
}
